// pages/Services.jsx

function ServicesPage({ navigate }) {
  const [hovered, setHovered] = React.useState(null);

  const categories = [
    { id: 'corte', name: 'Corte', num: '01', services: [
      { name: 'Corte Mujer', desc: 'Lavado, corte artístico y secado profesional', price: '$15.000' },
      { name: 'Corte Hombre', desc: 'Corte clásico con acabado y estilizado', price: '$10.000' },
      { name: 'Corte + Peinado', desc: 'Corte y styling para ocasiones especiales', price: '$22.000' },
      { name: 'Flequillo', desc: 'Reajuste de flequillo o puntas', price: '$5.000' },
    ]},
    { id: 'color', name: 'Color', num: '02', services: [
      { name: 'Tinte completo', desc: 'Color uniforme en toda la melena con productos premium', price: '$35.000' },
      { name: 'Balayage', desc: 'Técnica de aclarado degradado pintado a mano', price: '$60.000' },
      { name: 'Mechas', desc: 'Reflejos clásicos aplicados con papel de aluminio', price: '$45.000' },
      { name: 'Decoloración', desc: 'Aclarado profesional de base capilar', price: '$40.000' },
    ]},
    { id: 'tratamientos', name: 'Tratamientos', num: '03', services: [
      { name: 'Hidratación profunda', desc: 'Mascarilla nutritiva de alta penetración capilar', price: '$20.000' },
      { name: 'Keratina', desc: 'Alisado y nutrición intensiva sin formol', price: '$55.000' },
      { name: 'Botox capilar', desc: 'Relleno y restauración de la fibra capilar dañada', price: '$45.000' },
      { name: 'Olaplex', desc: 'Reconstrucción del enlace disulfuro capilar', price: '$30.000' },
    ]},
    { id: 'manicure', name: 'Manicure', num: '04', services: [
      { name: 'Manicure clásico', desc: 'Limpieza, modelado y esmaltado tradicional', price: '$8.000' },
      { name: 'Semipermanente', desc: 'Esmaltado en gel de larga duración', price: '$14.000' },
      { name: 'Pedicure', desc: 'Cuidado completo y estético de pies', price: '$15.000' },
      { name: 'Nail art', desc: 'Decoración artística personalizada', price: '$18.000' },
    ]},
  ];

  return (
    <div>
      {/* Header */}
      <section style={{ padding: '64px 40px 48px', borderBottom: '1px solid var(--border-default)' }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: '9px', fontWeight: 500, letterSpacing: '0.25em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '12px' }}>Catálogo</div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-5xl)', fontWeight: 300, lineHeight: 1, letterSpacing: '-0.03em' }}>Servicios</h1>
          </div>
          <button onClick={() => navigate('booking')} style={{ background: 'var(--color-black)', color: 'white', border: 'none', padding: '14px 32px', fontFamily: 'var(--font-body)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.2em', textTransform: 'uppercase', cursor: 'pointer' }}>
            Reservar hora
          </button>
        </div>
      </section>

      {/* Categories */}
      {categories.map((cat, ci) => (
        <section key={cat.id} style={{ borderBottom: '1px solid var(--border-default)' }}>
          <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 40px', display: 'grid', gridTemplateColumns: '240px 1fr' }}>
            {/* Category label */}
            <div style={{ padding: '40px 40px 40px 0', borderRight: '1px solid var(--border-subtle)' }}>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: '9px', fontWeight: 500, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '8px' }}>{cat.num}</div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-3xl)', fontWeight: 300 }}>{cat.name}</h2>
            </div>
            {/* Services */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', paddingLeft: '40px' }}>
              {cat.services.map((svc, si) => {
                const key = `${ci}-${si}`;
                const isTop = si < 2;
                const isLeft = si % 2 === 0;
                return (
                  <div key={si} onMouseEnter={() => setHovered(key)} onMouseLeave={() => setHovered(null)}
                    style={{ padding: '28px 0', borderBottom: isTop ? '1px solid var(--border-subtle)' : 'none', borderRight: isLeft ? '1px solid var(--border-subtle)' : 'none', paddingRight: isLeft ? '32px' : '0', paddingLeft: isLeft ? '0' : '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px', cursor: 'pointer', background: hovered === key ? 'var(--color-warm-50)' : 'transparent', transition: 'background 150ms ease', margin: isLeft ? '0 0 0 0' : '0' }}>
                    <div>
                      <div style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', fontWeight: 500, marginBottom: '4px' }}>{svc.name}</div>
                      <div style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', color: 'var(--text-muted)', lineHeight: 1.65 }}>{svc.desc}</div>
                    </div>
                    <div style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', fontWeight: 500, flexShrink: 0 }}>{svc.price}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      ))}

      {/* CTA */}
      <section style={{ padding: '96px 40px', textAlign: 'center', background: 'var(--color-warm-50)' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-4xl)', fontWeight: 300, marginBottom: '16px' }}>¿Lista para tu próxima visita?</h2>
        <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-base)', color: 'var(--text-secondary)', marginBottom: '40px' }}>Mar a Vie 9:30 – 19:00 · Sáb 10:00 – 18:00</p>
        <button onClick={() => navigate('booking')} style={{ background: 'var(--color-black)', color: 'white', border: 'none', padding: '16px 48px', fontFamily: 'var(--font-body)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.2em', textTransform: 'uppercase', cursor: 'pointer' }}>
          Agendar ahora
        </button>
      </section>
    </div>
  );
}

Object.assign(window, { ServicesPage });
