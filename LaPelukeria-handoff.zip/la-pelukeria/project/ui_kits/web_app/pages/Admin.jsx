// pages/Admin.jsx

function AdminPage({ navigate }) {
  const [section, setSection] = React.useState('citas');
  const [filter, setFilter]   = React.useState('todos');

  const appointments = [
    { id:1, time:'09:30', client:'María García',    service:'Corte + Peinado',     pro:'Eli',       status:'confirmed' },
    { id:2, time:'10:30', client:'Ana López',       service:'Balayage',            pro:'Ori',       status:'confirmed' },
    { id:3, time:'12:00', client:'Carolina Muñoz',  service:'Hidratación profunda', pro:'Eli',       status:'pending'   },
    { id:4, time:'13:30', client:'Valentina Rivas', service:'Tinte completo',      pro:'Ori',       status:'confirmed' },
    { id:5, time:'15:00', client:'— Almuerzo —',    service:'',                    pro:'',          status:'blocked'   },
    { id:6, time:'16:00', client:'Fernanda Castro', service:'Corte Mujer',         pro:'Eli',       status:'pending'   },
    { id:7, time:'17:00', client:'Daniela Torres',  service:'Semipermanente',      pro:'Valentina', status:'confirmed' },
    { id:8, time:'18:00', client:'Camila Vega',     service:'Nail art',            pro:'Valentina', status:'cancelled' },
  ];

  const services = [
    { cat:'Corte',        name:'Corte Mujer',    price:'$15.000', dur:'60 min' },
    { cat:'Corte',        name:'Corte Hombre',   price:'$10.000', dur:'45 min' },
    { cat:'Color',        name:'Balayage',        price:'$60.000', dur:'120 min'},
    { cat:'Color',        name:'Tinte completo',  price:'$35.000', dur:'90 min' },
    { cat:'Tratamientos', name:'Keratina',        price:'$55.000', dur:'120 min'},
    { cat:'Manicure',     name:'Semipermanente',  price:'$14.000', dur:'60 min' },
  ];

  const statusMeta = {
    confirmed: { label:'Confirmada', bg:'var(--status-confirmed-bg)', color:'var(--status-confirmed-text)', border:'var(--status-confirmed-border)' },
    pending:   { label:'Pendiente',  bg:'var(--status-pending-bg)',   color:'var(--status-pending-text)',   border:'var(--status-pending-border)'   },
    cancelled: { label:'Cancelada',  bg:'var(--status-cancelled-bg)', color:'var(--status-cancelled-text)', border:'var(--status-cancelled-border)' },
    blocked:   { label:'Bloqueada',  bg:'var(--status-blocked-bg)',   color:'var(--status-blocked-text)',   border:'var(--status-blocked-border)'   },
  };

  const navItems = ['dashboard','citas','servicios','bloqueos','configuración'];
  const visible = filter === 'todos' ? appointments : appointments.filter(a => a.status === filter);

  const stats = [
    { l:'Citas hoy',    v: appointments.filter(a => a.status !== 'blocked').length },
    { l:'Confirmadas',  v: appointments.filter(a => a.status === 'confirmed').length },
    { l:'Pendientes',   v: appointments.filter(a => a.status === 'pending').length },
    { l:'Canceladas',   v: appointments.filter(a => a.status === 'cancelled').length },
  ];

  const th = { fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', color:'var(--text-muted)' };

  return (
    <div style={{ display:'flex', height:'100vh', overflow:'hidden', fontFamily:'var(--font-body)' }}>

      {/* ── Sidebar ──────────────────────────────────────── */}
      <aside style={{ width:'var(--sidebar-width)', background:'var(--color-black)', color:'white', display:'flex', flexDirection:'column', flexShrink:0, borderRight:'1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ padding:'28px 24px', borderBottom:'1px solid rgba(255,255,255,0.07)' }}>
          <div style={{ fontFamily:'var(--font-display)', fontWeight:300, fontSize:'1.4rem', lineHeight:1, letterSpacing:'-0.03em' }}>LPk</div>
          <div style={{ fontFamily:'var(--font-body)', fontSize:'7px', fontWeight:500, letterSpacing:'0.22em', textTransform:'uppercase', marginTop:'4px', opacity:0.3 }}>Admin · La Pelukeria</div>
        </div>

        <nav style={{ padding:'12px 0', flex:1 }}>
          {navItems.map(item => (
            <button key={item} onClick={() => setSection(item)} style={{ display:'flex', alignItems:'center', width:'100%', padding:'12px 24px', background: section===item?'rgba(255,255,255,0.06)':'none', color: section===item?'white':'rgba(255,255,255,0.38)', border:'none', borderLeft: section===item?'2px solid white':'2px solid transparent', cursor:'pointer', fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', fontWeight:500, letterSpacing:'0.14em', textTransform:'uppercase', textAlign:'left', transition:'all 150ms ease' }}>
              {item.charAt(0).toUpperCase() + item.slice(1)}
            </button>
          ))}
        </nav>

        <div style={{ padding:'16px 24px', borderTop:'1px solid rgba(255,255,255,0.06)' }}>
          <button onClick={() => navigate('home')} style={{ fontFamily:'var(--font-body)', fontSize:'8px', fontWeight:500, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(255,255,255,0.2)', background:'none', border:'none', cursor:'pointer', padding:0 }}>
            ← Ver sitio
          </button>
        </div>
      </aside>

      {/* ── Main ─────────────────────────────────────────── */}
      <main style={{ flex:1, overflow:'auto', background:'var(--color-warm-50)' }}>
        {/* Topbar */}
        <div style={{ background:'white', borderBottom:'1px solid var(--border-default)', padding:'0 40px', height:'64px', display:'flex', alignItems:'center', justifyContent:'space-between', position:'sticky', top:0, zIndex:10 }}>
          <div>
            <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500 }}>Jueves 25 de junio, 2026</div>
            <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', color:'var(--text-muted)' }}>{appointments.filter(a=>a.status!=='blocked').length} citas programadas</div>
          </div>
          <button style={{ background:'var(--color-black)', color:'white', border:'none', padding:'10px 24px', fontFamily:'var(--font-body)', fontSize:'10px', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', cursor:'pointer' }}>
            + Nueva cita
          </button>
        </div>

        <div style={{ padding:'40px' }}>

          {/* Dashboard */}
          {section === 'dashboard' && (
            <div>
              <h1 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'32px' }}>Dashboard</h1>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'2px', background:'var(--border-default)', marginBottom:'40px' }}>
                {stats.map((s,i) => (
                  <div key={i} style={{ background:'white', padding:'24px 28px' }}>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', color:'var(--text-muted)', marginBottom:'10px' }}>{s.l}</div>
                    <div style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-4xl)', fontWeight:300 }}>{s.v}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Citas */}
          {section === 'citas' && (
            <div>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'24px' }}>
                <h1 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300 }}>Citas de hoy</h1>
                <div style={{ display:'flex', border:'1px solid var(--border-default)', background:'white' }}>
                  {[{k:'todos',l:'Todas'},{k:'confirmed',l:'Confirmadas'},{k:'pending',l:'Pendientes'}].map(f=>(
                    <button key={f.k} onClick={()=>setFilter(f.k)} style={{ padding:'8px 16px', fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.12em', textTransform:'uppercase', background: filter===f.k?'var(--color-black)':'transparent', color: filter===f.k?'white':'var(--text-secondary)', border:'none', borderRight:'1px solid var(--border-default)', cursor:'pointer', transition:'all 150ms' }}>{f.l}</button>
                  ))}
                </div>
              </div>

              <div style={{ background:'white', border:'1px solid var(--border-default)' }}>
                <div style={{ display:'grid', gridTemplateColumns:'72px 1fr 1fr 96px 120px 36px', padding:'12px 24px', borderBottom:'1px solid var(--border-default)', background:'var(--color-warm-50)' }}>
                  {['Hora','Cliente','Servicio','Profesional','Estado',''].map((h,i)=><div key={i} style={th}>{h}</div>)}
                </div>
                {visible.map((a, i) => {
                  const sm = statusMeta[a.status];
                  return (
                    <div key={a.id} style={{ display:'grid', gridTemplateColumns:'72px 1fr 1fr 96px 120px 36px', padding:'15px 24px', borderBottom: i<visible.length-1?'1px solid var(--border-subtle)':'none', alignItems:'center', background: a.status==='blocked'?'var(--color-warm-50)':'white', opacity: a.status==='cancelled'?0.55:1 }}>
                      <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500, color: a.status==='blocked'?'var(--text-muted)':'inherit' }}>{a.time}</div>
                      <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', textDecoration: a.status==='cancelled'?'line-through':'none', color: a.status==='blocked'?'var(--text-muted)':'inherit' }}>{a.client}</div>
                      <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', color:'var(--text-secondary)' }}>{a.service}</div>
                      <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', color:'var(--text-secondary)' }}>{a.pro}</div>
                      <div><span style={{ display:'inline-flex', alignItems:'center', padding:'3px 10px', fontFamily:'var(--font-body)', fontSize:'8px', fontWeight:500, letterSpacing:'0.12em', textTransform:'uppercase', background:sm.bg, color:sm.color, border:`1px solid ${sm.border}` }}>{sm.label}</span></div>
                      <div style={{ display:'flex', justifyContent:'flex-end' }}>
                        {a.status!=='blocked' && <button style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:'4px' }}>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                        </button>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Servicios */}
          {section === 'servicios' && (
            <div>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'24px' }}>
                <h1 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300 }}>Servicios</h1>
                <button style={{ background:'var(--color-black)', color:'white', border:'none', padding:'10px 24px', fontFamily:'var(--font-body)', fontSize:'10px', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', cursor:'pointer' }}>+ Agregar</button>
              </div>
              <div style={{ background:'white', border:'1px solid var(--border-default)' }}>
                <div style={{ display:'grid', gridTemplateColumns:'120px 1fr 96px 96px 80px', padding:'12px 24px', borderBottom:'1px solid var(--border-default)', background:'var(--color-warm-50)' }}>
                  {['Categoría','Servicio','Precio','Duración',''].map((h,i)=><div key={i} style={th}>{h}</div>)}
                </div>
                {services.map((s,i) => (
                  <div key={i} style={{ display:'grid', gridTemplateColumns:'120px 1fr 96px 96px 80px', padding:'16px 24px', borderBottom: i<services.length-1?'1px solid var(--border-subtle)':'none', alignItems:'center' }}>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--text-muted)' }}>{s.cat}</div>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500 }}>{s.name}</div>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)' }}>{s.price}</div>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', color:'var(--text-secondary)' }}>{s.dur}</div>
                    <div style={{ display:'flex', justifyContent:'flex-end' }}>
                      <button style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.1em', textTransform:'uppercase', background:'none', border:'1px solid var(--border-default)', padding:'6px 12px', cursor:'pointer', color:'var(--text-secondary)' }}>Editar</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bloqueos / Config */}
          {(section==='bloqueos'||section==='configuración') && (
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'60vh', flexDirection:'column', gap:'12px' }}>
              <h1 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, textTransform:'capitalize' }}>{section}</h1>
              <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', color:'var(--text-muted)' }}>Próximamente disponible.</p>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}

Object.assign(window, { AdminPage });
