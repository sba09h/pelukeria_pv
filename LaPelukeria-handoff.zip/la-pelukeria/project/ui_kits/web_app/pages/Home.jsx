// pages/Home.jsx — animated landing page (transitions, not animations, to survive re-renders)

function HomePage({ navigate }) {
  const [mounted, setMounted] = React.useState(false);
  const [svcVis,  setSvcVis]  = React.useState(false);
  const [galVis,  setGalVis]  = React.useState(false);
  const [hovSvc,  setHovSvc]  = React.useState(null);
  const [hovGal,  setHovGal]  = React.useState(null);
  const svcRef = React.useRef(null);
  const galRef = React.useRef(null);

  React.useEffect(() => {
    // Inject keyframes once — only blob/scan/bounce (NOT fade-up; those use CSS transitions)
    if (!document.getElementById('lpk-kf')) {
      const s = document.createElement('style');
      s.id = 'lpk-kf';
      s.textContent = `
        @keyframes lpkBlob1 {
          0%,100% { transform:translate(0,0) scale(1);          opacity:.42; }
          38%     { transform:translate(65px,-42px) scale(1.13); opacity:.64; }
          70%     { transform:translate(-18px,28px) scale(.93);  opacity:.34; }
        }
        @keyframes lpkBlob2 {
          0%,100% { transform:translate(0,0) scale(1);          opacity:.28; }
          34%     { transform:translate(-62px,46px) scale(1.2);  opacity:.46; }
          64%     { transform:translate(36px,-14px) scale(.9);   opacity:.22; }
        }
        @keyframes lpkBlob3 {
          0%,100% { transform:translate(0,0);        opacity:.16; }
          50%     { transform:translate(28px,-52px); opacity:.28; }
        }
        @keyframes lpkLineDraw {
          from { transform:scaleX(0); transform-origin:left center; }
          to   { transform:scaleX(1); transform-origin:left center; }
        }
        @keyframes lpkBounce {
          0%,100% { transform:translateX(-50%) translateY(0); }
          50%     { transform:translateX(-50%) translateY(7px); }
        }
      `;
      document.head.appendChild(s);
    }

    // Trigger hero transitions a frame after mount
    const t = setTimeout(() => setMounted(true), 60);

    // Scroll-reveal via IntersectionObserver
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.target === svcRef.current && e.isIntersecting) setSvcVis(true);
        if (e.target === galRef.current && e.isIntersecting) setGalVis(true);
      });
    }, { threshold: 0.12 });
    if (svcRef.current) io.observe(svcRef.current);
    if (galRef.current) io.observe(galRef.current);

    return () => { clearTimeout(t); io.disconnect(); };
  }, []);

  // CSS-transition based helpers — safe across re-renders (transitions don't restart
  // just because the transition property is written again with the same value)
  const fu = (d) => ({
    opacity:   mounted ? 1 : 0,
    transform: mounted ? 'translateY(0px)' : 'translateY(26px)',
    transition: `opacity .72s cubic-bezier(.16,1,.3,1) ${d}s, transform .72s cubic-bezier(.16,1,.3,1) ${d}s`,
  });

  const sr = (vis, d) => ({
    opacity:   vis ? 1 : 0,
    transform: vis ? 'translateY(0px)' : 'translateY(22px)',
    transition: `opacity .6s cubic-bezier(.16,1,.3,1) ${d}s, transform .6s cubic-bezier(.16,1,.3,1) ${d}s`,
  });

  const services = [
    { num: '01', name: 'Corte',        desc: 'Corte artístico adaptado a tu morfología facial y estilo de vida.',    price: 'desde $10.000' },
    { num: '02', name: 'Color',        desc: 'Técnicas de alta gama: Balayage, mechas, tinte, decoloración.',        price: 'desde $35.000' },
    { num: '03', name: 'Tratamientos', desc: 'Nutrición profunda y restauración de la fibra capilar.',               price: 'desde $20.000' },
  ];

  const tones = ['#1A1917','#2B2926','#E8E2DA','#1A1917','#C4B8A8','#3D3B37'];

  return (
    <div>
      {/* ═══════════════════════════════ HERO ════════════════════════════════ */}
      <section style={{ height: '100vh', background: '#0D0C0A', position: 'relative', overflow: 'hidden' }}>

        {/* Animated gradient blobs */}
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <div style={{ position:'absolute', width:'65%', height:'68%', top:'-10%', right:'-14%', background:'radial-gradient(ellipse, rgba(139,126,110,.44) 0%, rgba(107,103,96,.16) 42%, transparent 70%)', animation:'lpkBlob1 13s ease-in-out infinite', willChange:'transform' }} />
          <div style={{ position:'absolute', width:'56%', height:'58%', bottom:'-10%', left:'-14%', background:'radial-gradient(ellipse, rgba(80,72,60,.52) 0%, rgba(61,59,55,.2) 42%, transparent 70%)', animation:'lpkBlob2 18s ease-in-out infinite', willChange:'transform' }} />
          <div style={{ position:'absolute', width:'38%', height:'38%', top:'30%', left:'36%', background:'radial-gradient(ellipse, rgba(176,162,145,.15) 0%, transparent 70%)', animation:'lpkBlob3 22s ease-in-out infinite' }} />
          {/* Subtle pixel grid */}
          <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(255,255,255,.016) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.016) 1px, transparent 1px)', backgroundSize:'80px 80px' }} />
          {/* Bottom vignette */}
          <div style={{ position:'absolute', inset:0, background:'linear-gradient(to bottom, transparent 35%, rgba(10,9,8,.82) 100%)' }} />
          {/* Left edge vignette */}
          <div style={{ position:'absolute', inset:0, background:'linear-gradient(to right, rgba(10,9,8,.32) 0%, transparent 50%)' }} />
        </div>

        {/* Scan line */}
        {mounted && (
          <div style={{ position:'absolute', top:'38%', left:0, right:0, height:'1px', background:'linear-gradient(to right, transparent 0%, rgba(255,255,255,.055) 25%, rgba(255,255,255,.055) 75%, transparent 100%)', transformOrigin:'left center', animation:'lpkLineDraw 2s cubic-bezier(.16,1,.3,1) .1s both', pointerEvents:'none' }} />
        )}

        {/* Hero copy — bottom-left, staggered via CSS transitions */}
        <div style={{ position:'absolute', bottom:'84px', left:'56px', right:'50%', minWidth:'420px', zIndex:2 }}>
          <div style={{ fontFamily:'var(--font-body)', fontSize:'8px', fontWeight:500, letterSpacing:'0.35em', textTransform:'uppercase', color:'rgba(255,255,255,.36)', marginBottom:'18px', ...fu(0.28) }}>
            Puerto Varas · Chile
          </div>
          <div style={{ fontFamily:'var(--font-display)', fontWeight:300, fontSize:'clamp(54px,8.5vw,112px)', lineHeight:.88, letterSpacing:'-0.04em', color:'white', marginBottom:'4px', ...fu(0.45) }}>
            La
          </div>
          <div style={{ fontFamily:'var(--font-display)', fontWeight:300, fontSize:'clamp(54px,8.5vw,112px)', lineHeight:.88, letterSpacing:'-0.04em', color:'white', marginBottom:'22px', ...fu(0.58) }}>
            Pelukeria
          </div>
          <div style={{ fontFamily:'var(--font-display)', fontStyle:'italic', fontWeight:300, fontSize:'.95rem', color:'rgba(255,255,255,.3)', marginBottom:'40px', ...fu(0.8) }}>
            Hair Salon
          </div>
          <div style={{ display:'flex', gap:'10px', ...fu(1.0) }}>
            <button onClick={() => navigate('booking')}
              style={{ background:'rgba(255,255,255,.1)', color:'white', border:'1px solid rgba(255,255,255,.3)', padding:'13px 36px', fontFamily:'var(--font-body)', fontSize:'10px', fontWeight:500, letterSpacing:'0.2em', textTransform:'uppercase', cursor:'pointer', backdropFilter:'blur(10px)', WebkitBackdropFilter:'blur(10px)', transition:'all 200ms ease' }}
              onMouseEnter={e=>{e.currentTarget.style.background='rgba(255,255,255,.9)';e.currentTarget.style.color='#000';}}
              onMouseLeave={e=>{e.currentTarget.style.background='rgba(255,255,255,.1)';e.currentTarget.style.color='white';}}>
              Reservar hora
            </button>
            <button onClick={() => navigate('services')}
              style={{ background:'transparent', color:'rgba(255,255,255,.65)', border:'1px solid rgba(255,255,255,.15)', padding:'13px 28px', fontFamily:'var(--font-body)', fontSize:'10px', fontWeight:500, letterSpacing:'0.2em', textTransform:'uppercase', cursor:'pointer', transition:'all 200ms ease' }}
              onMouseEnter={e=>{e.currentTarget.style.color='white';e.currentTarget.style.borderColor='rgba(255,255,255,.32)';}}
              onMouseLeave={e=>{e.currentTarget.style.color='rgba(255,255,255,.65)';e.currentTarget.style.borderColor='rgba(255,255,255,.15)';}}>
              Ver servicios
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        {mounted && (
          <div style={{ position:'absolute', bottom:'28px', left:'50%', display:'flex', flexDirection:'column', alignItems:'center', gap:'8px', animation:'lpkBounce 2.2s ease-in-out 1.4s infinite', zIndex:2 }}>
            <div style={{ fontFamily:'var(--font-body)', fontSize:'7px', letterSpacing:'0.22em', textTransform:'uppercase', color:'rgba(255,255,255,.17)' }}>Scroll</div>
            <div style={{ width:'1px', height:'36px', background:'linear-gradient(to bottom, rgba(255,255,255,.14), transparent)' }} />
          </div>
        )}
      </section>

      {/* ══════════════════════════ SERVICES ═════════════════════════════════ */}
      <section ref={svcRef} style={{ padding:'96px 48px', maxWidth:'1280px', margin:'0 auto' }}>
        {/* Header */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:'48px', paddingBottom:'20px', borderBottom:'1px solid var(--border-default)', ...sr(svcVis, 0) }}>
          <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-4xl)', fontWeight:300, letterSpacing:'-0.02em' }}>Servicios</h2>
          <button onClick={() => navigate('services')} style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', color:'var(--text-secondary)', background:'none', border:'none', borderBottom:'1px solid var(--border-default)', paddingBottom:'1px', cursor:'pointer' }}>Ver todos →</button>
        </div>

        {/* Cards — sr() wrapper is separate from hover card to avoid transition conflicts */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'1px', background:'var(--border-default)' }}>
          {services.map((s, i) => (
            <div key={i} style={{ ...sr(svcVis, 0.1 + i * 0.1) }}>
              <div
                onMouseEnter={() => setHovSvc(i)} onMouseLeave={() => setHovSvc(null)}
                onClick={() => navigate('services')}
                style={{ height:'100%', background:hovSvc===i?'#000':'#fff', color:hovSvc===i?'white':'inherit', padding:'48px 40px', cursor:'pointer', transition:'background 220ms ease, color 220ms ease' }}>
                <div style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.2em', textTransform:'uppercase', color:hovSvc===i?'rgba(255,255,255,.3)':'var(--text-muted)', marginBottom:'20px' }}>{s.num}</div>
                <h3 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'14px' }}>{s.name}</h3>
                <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', lineHeight:1.75, color:hovSvc===i?'rgba(255,255,255,.5)':'var(--text-secondary)', marginBottom:'28px' }}>{s.desc}</p>
                <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500 }}>{s.price}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ══════════════════════════ GALLERY ══════════════════════════════════ */}
      <section ref={galRef} style={{ padding:'0 48px 96px', maxWidth:'1280px', margin:'0 auto' }}>
        {/* Header */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:'32px', paddingBottom:'20px', borderBottom:'1px solid var(--border-default)', ...sr(galVis, 0) }}>
          <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-4xl)', fontWeight:300, letterSpacing:'-0.02em' }}>Portfolio</h2>
          <button onClick={() => navigate('gallery')} style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', color:'var(--text-secondary)', background:'none', border:'none', borderBottom:'1px solid var(--border-default)', paddingBottom:'1px', cursor:'pointer' }}>Ver galería →</button>
        </div>

        {/* Grid — sr() wrapper, hover handled on inner div */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'2px' }}>
          {tones.map((tone, i) => (
            <div key={i} style={{ aspectRatio:'4/5', ...sr(galVis, 0.06 * i) }}>
              <div
                onMouseEnter={() => setHovGal(i)} onMouseLeave={() => setHovGal(null)}
                onClick={() => navigate('gallery')}
                style={{ width:'100%', height:'100%', background:tone, cursor:'pointer', transition:'opacity 250ms ease', opacity:hovGal!==null && hovGal!==i ? 0.6 : 1 }}
              />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { HomePage });
