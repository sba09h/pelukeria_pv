// pages/Booking.jsx

function BookingPage({ navigate }) {
  const [step, setStep] = React.useState(1);
  const [selectedCat, setSelectedCat]   = React.useState(null);
  const [selectedPro, setSelectedPro]   = React.useState(null);
  const [selectedDate, setSelectedDate] = React.useState(null);
  const [selectedTime, setSelectedTime] = React.useState(null);
  const [form, setForm] = React.useState({ name: '', phone: '', comment: '' });

  const categories = [
    { id: 'corte',        name: 'Corte',        price: 'desde $5.000' },
    { id: 'color',        name: 'Color',        price: 'desde $35.000' },
    { id: 'tratamientos', name: 'Tratamientos', price: 'desde $20.000' },
    { id: 'manicure',     name: 'Manicure',     price: 'desde $8.000' },
  ];

  const professionals = [
    { id: 'eli',       name: 'Eli',            role: 'Estilista',     init: 'E' },
    { id: 'ori',       name: 'Ori',            role: 'Colorista',     init: 'O' },
    { id: 'valentina', name: 'Valentina',      role: 'Manicurista',   init: 'V' },
    { id: 'any',       name: 'Sin preferencia',role: 'Primer disponible', init: '—' },
  ];

  // June 2026: rows Mon→Sun, June 1 = Monday
  const june = [
    [1,2,3,4,5,6,7],[8,9,10,11,12,13,14],
    [15,16,17,18,19,20,21],[22,23,24,25,26,27,28],
    [29,30,null,null,null,null,null],
  ];
  // di: 0=Mon … 5=Sat … 6=Sun  — closed Mon(0) and Sun(6)
  const closedDi = new Set([0, 6]);

  const times = ['09:30','10:30','11:30','12:30','13:30','14:30','15:30','16:30','17:30','18:00'];
  const booked = new Set(['10:30','13:30','16:30']);

  const stepLabels = ['Servicio','Profesional','Fecha','Hora','Datos'];

  const BtnFwd = ({ onClick, disabled, label }) => (
    <button onClick={onClick} disabled={disabled} style={{ background: disabled ? 'var(--color-warm-200)' : 'var(--color-black)', color: disabled ? 'var(--color-warm-500)' : 'white', border: 'none', padding: '14px 0', fontFamily: 'var(--font-body)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', cursor: disabled ? 'not-allowed' : 'pointer', flex: 2, transition: 'all 200ms ease' }}>{label || 'Continuar'}</button>
  );
  const BtnBack = ({ onClick }) => (
    <button onClick={onClick} style={{ background: 'transparent', color: 'var(--text-secondary)', border: '1px solid var(--border-default)', padding: '14px 0', fontFamily: 'var(--font-body)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', cursor: 'pointer', flex: 1 }}>Atrás</button>
  );

  // ── Confirmation ────────────────────────────────────────
  if (step === 6) {
    return (
      <div style={{ minHeight: 'calc(100vh - 72px)', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color-warm-50)' }}>
        <div style={{ textAlign: 'center', maxWidth: '480px', padding: '64px 32px' }}>
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--color-warm-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 32px' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12" /></svg>
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-4xl)', fontWeight: 300, marginBottom: '16px' }}>Reserva confirmada</h1>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', lineHeight: 1.75, marginBottom: '40px' }}>
            Te esperamos el {selectedDate && `${selectedDate} de junio`} a las <strong>{selectedTime} hrs</strong>.<br />
            Recibirás una confirmación por WhatsApp.
          </p>
          <div style={{ border: '1px solid var(--border-default)', padding: '24px', background: 'white', marginBottom: '32px', textAlign: 'left' }}>
            {[{l:'Servicio',v:selectedCat},{l:'Profesional',v:selectedPro},{l:'Fecha',v:selectedDate?`${selectedDate} Jun 2026`:''},{l:'Hora',v:selectedTime?`${selectedTime} hrs`:''},{l:'Nombre',v:form.name}].map((r,i)=>(
              <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderBottom: i<4?'1px solid var(--border-subtle)':'none' }}>
                <span style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--text-muted)' }}>{r.l}</span>
                <span style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', textTransform:'capitalize' }}>{r.v}</span>
              </div>
            ))}
          </div>
          <button onClick={() => navigate('home')} style={{ background:'var(--color-black)', color:'white', border:'none', padding:'14px 40px', fontFamily:'var(--font-body)', fontSize:'10px', fontWeight:500, letterSpacing:'0.2em', textTransform:'uppercase', cursor:'pointer' }}>Volver al inicio</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: 'calc(100vh - 72px)', background: 'var(--color-warm-50)', paddingBottom: '64px' }}>
      <div style={{ maxWidth: '720px', margin: '0 auto', padding: '64px 32px 0' }}>

        {/* Step indicator */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', marginBottom:'64px' }}>
          {stepLabels.map((label, i) => {
            const n = i + 1;
            const active = step === n, done = step > n;
            return (
              <React.Fragment key={label}>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:'8px' }}>
                  <div style={{ width:32, height:32, borderRadius:'50%', background: done||active ? 'var(--color-black)' : 'transparent', border:`1px solid ${done||active?'var(--color-black)':'var(--border-default)'}`, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-body)', fontSize:'11px', fontWeight:500, color: done||active?'white':'var(--text-muted)', transition:'all 200ms' }}>
                    {done ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg> : n}
                  </div>
                  <div style={{ fontFamily:'var(--font-body)', fontSize:'8px', fontWeight:500, letterSpacing:'0.12em', textTransform:'uppercase', color: active?'var(--text-primary)':'var(--text-muted)', whiteSpace:'nowrap' }}>{label}</div>
                </div>
                {i < stepLabels.length-1 && <div style={{ width:60, height:1, background: step>i+1?'var(--color-black)':'var(--border-default)', margin:'0 6px', marginBottom:'24px', transition:'background 300ms' }} />}
              </React.Fragment>
            );
          })}
        </div>

        {/* Card */}
        <div style={{ background:'white', border:'1px solid var(--border-default)', padding:'48px' }}>

          {/* Step 1 — Servicio */}
          {step === 1 && (
            <div>
              <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'8px' }}>Elige un servicio</h2>
              <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', color:'var(--text-secondary)', marginBottom:'40px' }}>Selecciona la categoría que te interesa.</p>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'2px', background:'var(--border-default)', marginBottom:'40px' }}>
                {categories.map(cat => (
                  <div key={cat.id} onClick={() => setSelectedCat(cat.id)} style={{ background: selectedCat===cat.id?'var(--color-black)':'white', color: selectedCat===cat.id?'white':'inherit', padding:'32px 28px', cursor:'pointer', transition:'all 150ms ease' }}>
                    <div style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-2xl)', fontWeight:300, marginBottom:'4px' }}>{cat.name}</div>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', color: selectedCat===cat.id?'rgba(255,255,255,0.45)':'var(--text-muted)' }}>{cat.price}</div>
                  </div>
                ))}
              </div>
              <BtnFwd disabled={!selectedCat} onClick={() => setStep(2)} />
            </div>
          )}

          {/* Step 2 — Profesional */}
          {step === 2 && (
            <div>
              <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'8px' }}>Elige un profesional</h2>
              <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', color:'var(--text-secondary)', marginBottom:'40px' }}>Todos son expertos en su especialidad.</p>
              <div style={{ display:'flex', flexDirection:'column', gap:'2px', background:'var(--border-default)', marginBottom:'40px' }}>
                {professionals.map(pro => (
                  <div key={pro.id} onClick={() => setSelectedPro(pro.id)} style={{ background: selectedPro===pro.id?'var(--color-black)':'white', color: selectedPro===pro.id?'white':'inherit', padding:'18px 24px', cursor:'pointer', display:'flex', alignItems:'center', gap:'16px', transition:'all 150ms ease' }}>
                    <div style={{ width:40, height:40, borderRadius:'50%', background: selectedPro===pro.id?'rgba(255,255,255,0.12)':'var(--color-warm-100)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-body)', fontSize:'13px', fontWeight:500, color: selectedPro===pro.id?'white':'var(--color-warm-600)', flexShrink:0 }}>{pro.init}</div>
                    <div>
                      <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500 }}>{pro.name}</div>
                      <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-xs)', color: selectedPro===pro.id?'rgba(255,255,255,0.45)':'var(--text-muted)', marginTop:'2px' }}>{pro.role}</div>
                    </div>
                    {selectedPro===pro.id && <div style={{ marginLeft:'auto' }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg></div>}
                  </div>
                ))}
              </div>
              <div style={{ display:'flex', gap:'10px' }}><BtnBack onClick={() => setStep(1)} /><BtnFwd disabled={!selectedPro} onClick={() => setStep(3)} /></div>
            </div>
          )}

          {/* Step 3 — Fecha */}
          {step === 3 && (
            <div>
              <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'8px' }}>Elige una fecha</h2>
              <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', color:'var(--text-secondary)', marginBottom:'40px' }}>Atendemos Mar–Vie 9:30–19:00 · Sáb 10:00–18:00</p>
              <div style={{ marginBottom:'40px' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' }}>
                  <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500 }}>Junio 2026</div>
                </div>
                {/* Day headers */}
                <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:'2px', marginBottom:'4px' }}>
                  {['L','M','X','J','V','S','D'].map(d => (
                    <div key={d} style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.1em', color:'var(--text-muted)', textAlign:'center', padding:'6px 0' }}>{d}</div>
                  ))}
                </div>
                {/* Weeks */}
                {june.map((week, wi) => (
                  <div key={wi} style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:'2px', marginBottom:'2px' }}>
                    {week.map((day, di) => {
                      const isClosed = closedDi.has(di);
                      const isPast = day && day < 25;
                      const isDisabled = !day || isClosed || isPast;
                      const isSelected = selectedDate === day;
                      const isToday = day === 25;
                      return (
                        <div key={di} onClick={() => !isDisabled && setSelectedDate(day)} style={{ height:40, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', cursor: isDisabled?'default':'pointer', opacity: isDisabled?0.22:1, background: isSelected?'var(--color-black)': isToday&&!isSelected?'var(--color-warm-100)':'transparent', color: isSelected?'white':'inherit', fontWeight: isToday?500:400, transition:'all 150ms', userSelect:'none' }}>
                          {day}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
              <div style={{ display:'flex', gap:'10px' }}><BtnBack onClick={() => setStep(2)} /><BtnFwd disabled={!selectedDate} onClick={() => setStep(4)} /></div>
            </div>
          )}

          {/* Step 4 — Hora */}
          {step === 4 && (
            <div>
              <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'8px' }}>Elige una hora</h2>
              <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', color:'var(--text-secondary)', marginBottom:'40px' }}>{selectedDate ? `Jueves ${selectedDate} de junio` : 'Horarios disponibles'}</p>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'2px', background:'var(--border-default)', marginBottom:'40px' }}>
                {times.map(t => {
                  const taken = booked.has(t), sel = selectedTime===t;
                  return (
                    <div key={t} onClick={() => !taken && setSelectedTime(t)} style={{ background: sel?'var(--color-black)': taken?'var(--color-warm-50)':'white', color: sel?'white': taken?'var(--color-warm-300)':'inherit', padding:'18px 8px', textAlign:'center', cursor: taken?'not-allowed':'pointer', fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight: sel?500:400, transition:'all 150ms ease' }}>
                      <div>{t}</div>
                      {taken && <div style={{ fontSize:'8px', marginTop:'2px', letterSpacing:'0.05em' }}>Ocupado</div>}
                    </div>
                  );
                })}
              </div>
              <div style={{ display:'flex', gap:'10px' }}><BtnBack onClick={() => setStep(3)} /><BtnFwd disabled={!selectedTime} onClick={() => setStep(5)} /></div>
            </div>
          )}

          {/* Step 5 — Datos */}
          {step === 5 && (
            <div>
              <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--text-3xl)', fontWeight:300, marginBottom:'8px' }}>Tus datos</h2>
              <p style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', color:'var(--text-secondary)', marginBottom:'40px' }}>Solo lo necesario para confirmar tu reserva.</p>
              <div style={{ display:'flex', flexDirection:'column', gap:'32px', marginBottom:'32px' }}>
                {[{label:'Nombre completo',key:'name',type:'text',ph:'Tu nombre'},{label:'Teléfono',key:'phone',type:'tel',ph:'+56 9 XXXX XXXX'},{label:'Comentario',key:'comment',type:'text',ph:'Opcional — alergias, largo del cabello...'}].map(f=>(
                  <div key={f.key} style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
                    <label style={{ fontFamily:'var(--font-body)', fontSize:'9px', fontWeight:500, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--text-secondary)' }}>{f.label}</label>
                    <input type={f.type} placeholder={f.ph} value={form[f.key]} onChange={e=>setForm(prev=>({...prev,[f.key]:e.target.value}))} style={{ background:'transparent', border:'none', borderBottom:'1px solid var(--border-default)', padding:'10px 0', fontFamily:'var(--font-body)', fontSize:'var(--text-base)', outline:'none', width:'100%', color:'var(--text-primary)' }} />
                  </div>
                ))}
              </div>
              {/* Summary */}
              <div style={{ background:'var(--color-warm-50)', border:'1px solid var(--border-subtle)', padding:'16px 20px', marginBottom:'32px', display:'flex', gap:'24px', flexWrap:'wrap' }}>
                {[{l:'Servicio',v:selectedCat},{l:'Profesional',v:selectedPro},{l:'Fecha',v:selectedDate?`${selectedDate} Jun`:''},{l:'Hora',v:selectedTime}].map((r,i)=>(
                  <div key={i}>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'8px', fontWeight:500, letterSpacing:'0.15em', textTransform:'uppercase', color:'var(--text-muted)', marginBottom:'2px' }}>{r.l}</div>
                    <div style={{ fontFamily:'var(--font-body)', fontSize:'var(--text-sm)', fontWeight:500, textTransform:'capitalize' }}>{r.v}</div>
                  </div>
                ))}
              </div>
              <div style={{ display:'flex', gap:'10px' }}><BtnBack onClick={() => setStep(4)} /><BtnFwd disabled={!form.name||!form.phone} onClick={() => setStep(6)} label="Confirmar reserva" /></div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

Object.assign(window, { BookingPage });
