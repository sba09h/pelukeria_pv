// pages/Gallery.jsx

function GalleryPage({ navigate }) {
  const [filter, setFilter] = React.useState('todos');
  const [hoveredItem, setHoveredItem] = React.useState(null);

  const filters = [
    { key: 'todos',       label: 'Todos' },
    { key: 'corte',       label: 'Corte' },
    { key: 'color',       label: 'Color' },
    { key: 'tratamientos',label: 'Tratamientos' },
    { key: 'manicure',    label: 'Manicure' },
  ];

  const items = [
    { cat: 'color',        tone: '#1A1917', label: 'Balayage' },
    { cat: 'corte',        tone: '#2B2926', label: 'Corte Mujer' },
    { cat: 'color',        tone: '#E8E2DA', label: 'Mechas' },
    { cat: 'tratamientos', tone: '#C4B8A8', label: 'Keratina' },
    { cat: 'corte',        tone: '#3D3B37', label: 'Corte + Peinado' },
    { cat: 'manicure',     tone: '#F4F2EE', label: 'Semipermanente' },
    { cat: 'color',        tone: '#1A1917', label: 'Tinte completo' },
    { cat: 'corte',        tone: '#8B7E6E', label: 'Corte Hombre' },
    { cat: 'color',        tone: '#2B2926', label: 'Balayage' },
    { cat: 'manicure',     tone: '#E2DED8', label: 'Nail art' },
    { cat: 'tratamientos', tone: '#1A1917', label: 'Hidratación' },
    { cat: 'color',        tone: '#C4B8A8', label: 'Decoloración' },
  ];

  const visible = filter === 'todos' ? items : items.filter(it => it.cat === filter);

  return (
    <div>
      {/* Header */}
      <section style={{ padding: '64px 40px 0', borderBottom: '1px solid var(--border-default)' }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', paddingBottom: '40px' }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '9px', fontWeight: 500, letterSpacing: '0.25em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '12px' }}>Portfolio</div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-5xl)', fontWeight: 300, lineHeight: 1, letterSpacing: '-0.03em' }}>Galería</h1>
        </div>

        {/* Filters */}
        <div style={{ maxWidth: '1280px', margin: '0 auto', display: 'flex', gap: '0' }}>
          {filters.map(f => (
            <button key={f.key} onClick={() => setFilter(f.key)} style={{
              fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', fontWeight: 500, letterSpacing: '0.15em', textTransform: 'uppercase',
              padding: '18px 24px', background: 'none', border: 'none', cursor: 'pointer',
              color: filter === f.key ? 'var(--text-primary)' : 'var(--text-muted)',
              borderBottom: filter === f.key ? '1px solid var(--color-black)' : '1px solid transparent',
              marginBottom: '-1px', transition: 'color 150ms ease',
            }}>
              {f.label}
            </button>
          ))}
        </div>
      </section>

      {/* Grid */}
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '2px 40px 96px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '2px', marginTop: '2px' }}>
          {visible.map((item, i) => (
            <div key={`${filter}-${i}`} onMouseEnter={() => setHoveredItem(i)} onMouseLeave={() => setHoveredItem(null)}
              style={{ aspectRatio: '4/5', background: item.tone, position: 'relative', overflow: 'hidden', cursor: 'pointer' }}>
              {/* Hover overlay */}
              <div style={{ position: 'absolute', inset: 0, background: 'rgba(13,12,10,0.65)', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: '24px', opacity: hoveredItem === i ? 1 : 0, transition: 'opacity 200ms ease' }}>
                <div style={{ fontFamily: 'var(--font-body)', fontSize: '8px', fontWeight: 500, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', marginBottom: '4px' }}>{item.cat}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 300, color: 'white' }}>{item.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GalleryPage });
