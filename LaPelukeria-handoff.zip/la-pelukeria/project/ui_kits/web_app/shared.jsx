// shared.jsx — Navbar & Footer (with adaptive glass style for home hero)

function LPKLogo({ color = 'var(--color-black)', onClick }) {
  return (
    <div onClick={onClick} style={{ cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '2px' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 300, fontSize: '1.4rem', lineHeight: 1, letterSpacing: '-0.03em', color, transition: 'color 350ms ease' }}>LPk</div>
      <div style={{ fontFamily: 'var(--font-body)', fontSize: '7px', fontWeight: 500, letterSpacing: '0.24em', textTransform: 'uppercase', color, opacity: 0.55, transition: 'color 350ms ease' }}>La Pelukeria</div>
    </div>
  );
}

function LPKNavbar({ navigate, currentPage }) {
  const [scrolled, setScrolled] = React.useState(false);
  const [btnHov, setBtnHov] = React.useState(false);

  // On home page, track scroll to flip between glass-dark and glass-light
  React.useEffect(() => {
    if (currentPage !== 'home') { setScrolled(false); return; }
    const check = () => setScrolled(window.scrollY > window.innerHeight * 0.72);
    check();
    window.addEventListener('scroll', check, { passive: true });
    return () => window.removeEventListener('scroll', check);
  }, [currentPage]);

  const isHome = currentPage === 'home';
  const dark   = isHome && !scrolled;   // dark glass overlay on hero

  // Colors that transition between dark/light modes
  const fg        = dark ? 'rgba(255,255,255,0.9)' : 'var(--color-black)';
  const fgMuted   = dark ? 'rgba(255,255,255,0.45)' : 'var(--text-secondary)';
  const activeBdr = dark ? 'rgba(255,255,255,0.7)' : 'var(--color-black)';

  const links = [
    { key: 'home',     label: 'Inicio'    },
    { key: 'services', label: 'Servicios' },
    { key: 'gallery',  label: 'Galería'   },
  ];

  return (
    <nav style={{
      position: isHome ? 'fixed' : 'sticky',
      top: 0, width: '100%', zIndex: 100,
      height: 'var(--navbar-height)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 48px',
      background: dark
        ? 'rgba(13,12,10,0.28)'
        : 'rgba(255,255,255,0.94)',
      backdropFilter: 'blur(22px)',
      WebkitBackdropFilter: 'blur(22px)',
      borderBottom: dark
        ? '1px solid rgba(255,255,255,0.07)'
        : '1px solid var(--border-default)',
      transition: 'background 420ms ease, border-color 420ms ease',
    }}>
      <LPKLogo color={fg} onClick={() => navigate('home')} />

      <div style={{ display: 'flex', gap: '40px' }}>
        {links.map(link => {
          const active = currentPage === link.key;
          return (
            <button key={link.key} onClick={() => navigate(link.key)} style={{
              fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', fontWeight: 'var(--fw-medium)',
              letterSpacing: 'var(--ls-wider)', textTransform: 'uppercase',
              color: active ? fg : fgMuted,
              background: 'none', border: 'none',
              borderBottom: active ? `1px solid ${activeBdr}` : '1px solid transparent',
              paddingBottom: '2px', cursor: 'pointer',
              transition: 'color 300ms ease, border-color 300ms ease',
            }}>
              {link.label}
            </button>
          );
        })}
      </div>

      <button
        onMouseEnter={() => setBtnHov(true)}
        onMouseLeave={() => setBtnHov(false)}
        onClick={() => navigate('booking')}
        style={{
          background: dark
            ? (btnHov ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.1)')
            : (btnHov ? 'transparent'            : 'var(--color-black)'),
          color: dark
            ? (btnHov ? 'var(--color-black)' : 'rgba(255,255,255,0.9)')
            : (btnHov ? 'var(--color-black)' : 'white'),
          border: dark
            ? '1px solid rgba(255,255,255,0.28)'
            : '1px solid var(--color-black)',
          padding: '10px 26px',
          fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', fontWeight: 'var(--fw-medium)',
          letterSpacing: 'var(--ls-widest)', textTransform: 'uppercase', cursor: 'pointer',
          transition: 'all 250ms ease',
          backdropFilter: dark ? 'blur(10px)' : 'none',
        }}>
        Reservar
      </button>
    </nav>
  );
}

function LPKFooter({ navigate }) {
  const col = { fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'rgba(255,255,255,0.45)', lineHeight: 2 };
  const colLabel = { fontFamily: 'var(--font-body)', fontSize: '8px', fontWeight: 500, letterSpacing: '0.22em', textTransform: 'uppercase', opacity: 0.3, marginBottom: '14px', display: 'block' };

  return (
    <footer style={{ background: 'var(--color-warm-950)', color: 'white', padding: '64px 48px 28px' }}>
      <div style={{ maxWidth: '1280px', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: '48px', paddingBottom: '40px', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
          <div>
            <LPKLogo color="white" />
            <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'rgba(255,255,255,0.35)', lineHeight: 1.8, maxWidth: '280px', marginTop: '20px' }}>
              Hair salon moderno y minimalista en Puerto Varas. Corte, color y tratamientos de alta gama.
            </p>
          </div>
          <div>
            <span style={colLabel}>Horario</span>
            <div style={col}>
              <div>Mar – Vie · 9:30 – 19:00</div>
              <div>Sábado · 10:00 – 18:00</div>
              <div style={{ opacity: 0.4 }}>Lun – Dom · Cerrado</div>
            </div>
          </div>
          <div>
            <span style={colLabel}>Contacto</span>
            <div style={col}>
              <div>Puerto Varas, Chile</div>
              <div>+56 9 2999 3799</div>
              <div>@lapelukeria_pv</div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '20px' }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '9px', color: 'rgba(255,255,255,0.18)', letterSpacing: '0.1em' }}>© 2026 La Pelukeria · Puerto Varas</div>
          <button onClick={() => navigate('admin')} style={{ fontFamily: 'var(--font-body)', fontSize: '8px', color: 'rgba(255,255,255,0.15)', letterSpacing: '0.12em', textTransform: 'uppercase', background: 'none', border: 'none', cursor: 'pointer' }}>Admin ↗</button>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { LPKLogo, LPKNavbar, LPKFooter });
