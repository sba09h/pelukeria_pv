/* @ds-bundle: {"format":3,"namespace":"LaPelukeria_00863f","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"a8e18f788772","components/core/Badge.jsx":"8d1bdd1b8b24","components/core/Button.jsx":"33e8e5559edf","components/core/Card.jsx":"2a56938d624a","components/core/Input.jsx":"e754cf0f8bea","ui_kits/web_app/pages/Admin.jsx":"7ccd704b16c1","ui_kits/web_app/pages/Booking.jsx":"68feba8a4edd","ui_kits/web_app/pages/Gallery.jsx":"30c620403f14","ui_kits/web_app/pages/Home.jsx":"5e57f990bbdf","ui_kits/web_app/pages/Services.jsx":"6b507037708b","ui_kits/web_app/shared.jsx":"ea4b403a6404"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LaPelukeria_00863f = window.LaPelukeria_00863f || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Avatar({
  src,
  name = '',
  size = 'md',
  shape = 'circle',
  ...props
}) {
  const sizes = {
    xs: 24,
    sm: 32,
    md: 40,
    lg: 56,
    xl: 72
  };
  const px = sizes[size] ?? 40;
  const initials = name.split(' ').filter(Boolean).map(w => w[0].toUpperCase()).slice(0, 2).join('');
  const radius = shape === 'circle' ? '50%' : shape === 'square' ? '0' : 'var(--radius-md)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: px,
      height: px,
      borderRadius: radius,
      background: src ? 'transparent' : 'var(--color-warm-200)',
      color: 'var(--color-warm-700)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-body)',
      fontSize: px * 0.35,
      fontWeight: 'var(--fw-medium)',
      overflow: 'hidden',
      flexShrink: 0,
      userSelect: 'none',
      border: src ? 'none' : '1px solid var(--border-default)'
    }
  }, props), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials || '?');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function Badge({
  status = 'pending',
  children
}) {
  const styles = {
    pending: {
      background: 'var(--status-pending-bg)',
      color: 'var(--status-pending-text)',
      border: '1px solid var(--status-pending-border)'
    },
    confirmed: {
      background: 'var(--status-confirmed-bg)',
      color: 'var(--status-confirmed-text)',
      border: '1px solid var(--status-confirmed-border)'
    },
    cancelled: {
      background: 'var(--status-cancelled-bg)',
      color: 'var(--status-cancelled-text)',
      border: '1px solid var(--status-cancelled-border)',
      textDecoration: 'line-through'
    },
    blocked: {
      background: 'var(--status-blocked-bg)',
      color: 'var(--status-blocked-text)',
      border: '1px solid var(--status-blocked-border)'
    },
    new: {
      background: 'transparent',
      color: 'var(--color-black)',
      border: '1px solid var(--color-black)'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '3px 10px',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: 'var(--ls-wider)',
      textTransform: 'uppercase',
      borderRadius: 'var(--badge-radius)',
      whiteSpace: 'nowrap',
      ...styles[status]
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  onClick,
  children,
  ...props
}) {
  const [hovered, setHovered] = React.useState(false);
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--fw-medium)',
    fontSize: 'var(--text-xs)',
    letterSpacing: 'var(--ls-widest)',
    textTransform: 'uppercase',
    border: '1px solid',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--transition-base), color var(--transition-base), border-color var(--transition-base)',
    whiteSpace: 'nowrap',
    userSelect: 'none',
    width: fullWidth ? '100%' : undefined,
    borderRadius: 'var(--button-radius)'
  };
  const sizes = {
    sm: {
      padding: 'var(--button-py-sm) var(--button-px-sm)'
    },
    md: {
      padding: 'var(--button-py) var(--button-px)'
    },
    lg: {
      padding: 'var(--button-py-lg) var(--button-px-lg)'
    }
  };
  const resting = {
    primary: {
      background: 'var(--color-black)',
      color: 'var(--color-white)',
      borderColor: 'var(--color-black)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--color-black)',
      borderColor: 'var(--color-black)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      borderColor: 'transparent'
    },
    'dark-inverse': {
      background: 'var(--color-white)',
      color: 'var(--color-black)',
      borderColor: 'var(--color-white)'
    }
  };
  const hover = {
    primary: {
      background: 'var(--color-white)',
      color: 'var(--color-black)',
      borderColor: 'var(--color-black)'
    },
    secondary: {
      background: 'var(--color-black)',
      color: 'var(--color-white)',
      borderColor: 'var(--color-black)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-primary)',
      borderColor: 'transparent'
    },
    'dark-inverse': {
      background: 'var(--color-warm-100)',
      color: 'var(--color-black)',
      borderColor: 'var(--color-warm-100)'
    }
  };
  const variantStyle = hovered && !disabled ? hover[variant] : resting[variant];
  return /*#__PURE__*/React.createElement("button", _extends({
    style: {
      ...base,
      ...sizes[size],
      ...variantStyle
    },
    disabled: disabled,
    onClick: !disabled ? onClick : undefined,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false)
  }, props), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  variant = 'default',
  padding = 'md',
  hover = false,
  onClick,
  style: extraStyle,
  children,
  ...props
}) {
  const [hovered, setHovered] = React.useState(false);
  const variants = {
    default: {
      background: 'var(--bg-primary)',
      border: '1px solid var(--border-default)',
      boxShadow: 'var(--card-shadow)'
    },
    flat: {
      background: 'var(--bg-secondary)',
      border: 'none',
      boxShadow: 'none'
    },
    dark: {
      background: 'var(--bg-dark)',
      border: 'none',
      boxShadow: 'none'
    },
    outlined: {
      background: 'transparent',
      border: '1px solid var(--border-default)',
      boxShadow: 'none'
    }
  };
  const paddings = {
    none: '0',
    sm: 'var(--space-4)',
    md: 'var(--card-p)',
    lg: 'var(--card-p-lg)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    onClick: onClick,
    style: {
      ...variants[variant],
      padding: paddings[padding],
      borderRadius: 'var(--card-radius)',
      transition: 'box-shadow var(--transition-base), transform var(--transition-base)',
      cursor: onClick ? 'pointer' : undefined,
      ...(hover && hovered ? {
        boxShadow: 'var(--card-shadow-hover)',
        transform: 'translateY(-1px)'
      } : {}),
      ...extraStyle
    }
  }, props), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  placeholder,
  type = 'text',
  value,
  onChange,
  error,
  helperText,
  disabled = false,
  ...props
}) {
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '4px'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: 'var(--ls-widest)',
      textTransform: 'uppercase',
      color: error ? '#8B3A3A' : focused ? 'var(--text-primary)' : 'var(--text-secondary)',
      transition: 'color var(--transition-fast)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      width: '100%',
      background: 'transparent',
      border: 'none',
      borderBottom: `1px solid ${error ? '#8B3A3A' : focused ? 'var(--color-black)' : 'var(--border-default)'}`,
      padding: 'var(--input-py) var(--input-px)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-primary)',
      outline: 'none',
      transition: 'border-color var(--transition-fast)',
      opacity: disabled ? 0.4 : 1,
      cursor: disabled ? 'not-allowed' : 'auto',
      borderRadius: 0
    }
  }, props)), (error || helperText) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      color: error ? '#8B3A3A' : 'var(--text-muted)',
      lineHeight: 'var(--lh-normal)'
    }
  }, error || helperText));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/pages/Admin.jsx
try { (() => {
// pages/Admin.jsx

function AdminPage({
  navigate
}) {
  const [section, setSection] = React.useState('citas');
  const [filter, setFilter] = React.useState('todos');
  const appointments = [{
    id: 1,
    time: '09:30',
    client: 'María García',
    service: 'Corte + Peinado',
    pro: 'Eli',
    status: 'confirmed'
  }, {
    id: 2,
    time: '10:30',
    client: 'Ana López',
    service: 'Balayage',
    pro: 'Ori',
    status: 'confirmed'
  }, {
    id: 3,
    time: '12:00',
    client: 'Carolina Muñoz',
    service: 'Hidratación profunda',
    pro: 'Eli',
    status: 'pending'
  }, {
    id: 4,
    time: '13:30',
    client: 'Valentina Rivas',
    service: 'Tinte completo',
    pro: 'Ori',
    status: 'confirmed'
  }, {
    id: 5,
    time: '15:00',
    client: '— Almuerzo —',
    service: '',
    pro: '',
    status: 'blocked'
  }, {
    id: 6,
    time: '16:00',
    client: 'Fernanda Castro',
    service: 'Corte Mujer',
    pro: 'Eli',
    status: 'pending'
  }, {
    id: 7,
    time: '17:00',
    client: 'Daniela Torres',
    service: 'Semipermanente',
    pro: 'Valentina',
    status: 'confirmed'
  }, {
    id: 8,
    time: '18:00',
    client: 'Camila Vega',
    service: 'Nail art',
    pro: 'Valentina',
    status: 'cancelled'
  }];
  const services = [{
    cat: 'Corte',
    name: 'Corte Mujer',
    price: '$15.000',
    dur: '60 min'
  }, {
    cat: 'Corte',
    name: 'Corte Hombre',
    price: '$10.000',
    dur: '45 min'
  }, {
    cat: 'Color',
    name: 'Balayage',
    price: '$60.000',
    dur: '120 min'
  }, {
    cat: 'Color',
    name: 'Tinte completo',
    price: '$35.000',
    dur: '90 min'
  }, {
    cat: 'Tratamientos',
    name: 'Keratina',
    price: '$55.000',
    dur: '120 min'
  }, {
    cat: 'Manicure',
    name: 'Semipermanente',
    price: '$14.000',
    dur: '60 min'
  }];
  const statusMeta = {
    confirmed: {
      label: 'Confirmada',
      bg: 'var(--status-confirmed-bg)',
      color: 'var(--status-confirmed-text)',
      border: 'var(--status-confirmed-border)'
    },
    pending: {
      label: 'Pendiente',
      bg: 'var(--status-pending-bg)',
      color: 'var(--status-pending-text)',
      border: 'var(--status-pending-border)'
    },
    cancelled: {
      label: 'Cancelada',
      bg: 'var(--status-cancelled-bg)',
      color: 'var(--status-cancelled-text)',
      border: 'var(--status-cancelled-border)'
    },
    blocked: {
      label: 'Bloqueada',
      bg: 'var(--status-blocked-bg)',
      color: 'var(--status-blocked-text)',
      border: 'var(--status-blocked-border)'
    }
  };
  const navItems = ['dashboard', 'citas', 'servicios', 'bloqueos', 'configuración'];
  const visible = filter === 'todos' ? appointments : appointments.filter(a => a.status === filter);
  const stats = [{
    l: 'Citas hoy',
    v: appointments.filter(a => a.status !== 'blocked').length
  }, {
    l: 'Confirmadas',
    v: appointments.filter(a => a.status === 'confirmed').length
  }, {
    l: 'Pendientes',
    v: appointments.filter(a => a.status === 'pending').length
  }, {
    l: 'Canceladas',
    v: appointments.filter(a => a.status === 'cancelled').length
  }];
  const th = {
    fontFamily: 'var(--font-body)',
    fontSize: '9px',
    fontWeight: 500,
    letterSpacing: '0.15em',
    textTransform: 'uppercase',
    color: 'var(--text-muted)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100vh',
      overflow: 'hidden',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 'var(--sidebar-width)',
      background: 'var(--color-black)',
      color: 'white',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      borderRight: '1px solid rgba(255,255,255,0.06)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '28px 24px',
      borderBottom: '1px solid rgba(255,255,255,0.07)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: '1.4rem',
      lineHeight: 1,
      letterSpacing: '-0.03em'
    }
  }, "LPk"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '7px',
      fontWeight: 500,
      letterSpacing: '0.22em',
      textTransform: 'uppercase',
      marginTop: '4px',
      opacity: 0.3
    }
  }, "Admin \xB7 La Pelukeria")), /*#__PURE__*/React.createElement("nav", {
    style: {
      padding: '12px 0',
      flex: 1
    }
  }, navItems.map(item => /*#__PURE__*/React.createElement("button", {
    key: item,
    onClick: () => setSection(item),
    style: {
      display: 'flex',
      alignItems: 'center',
      width: '100%',
      padding: '12px 24px',
      background: section === item ? 'rgba(255,255,255,0.06)' : 'none',
      color: section === item ? 'white' : 'rgba(255,255,255,0.38)',
      border: 'none',
      borderLeft: section === item ? '2px solid white' : '2px solid transparent',
      cursor: 'pointer',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 500,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      textAlign: 'left',
      transition: 'all 150ms ease'
    }
  }, item.charAt(0).toUpperCase() + item.slice(1)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 24px',
      borderTop: '1px solid rgba(255,255,255,0.06)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('home'),
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '8px',
      fontWeight: 500,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,0.2)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0
    }
  }, "\u2190 Ver sitio"))), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      overflow: 'auto',
      background: 'var(--color-warm-50)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'white',
      borderBottom: '1px solid var(--border-default)',
      padding: '0 40px',
      height: '64px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500
    }
  }, "Jueves 25 de junio, 2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, appointments.filter(a => a.status !== 'blocked').length, " citas programadas")), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'var(--color-black)',
      color: 'white',
      border: 'none',
      padding: '10px 24px',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      cursor: 'pointer'
    }
  }, "+ Nueva cita")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px'
    }
  }, section === 'dashboard' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '32px'
    }
  }, "Dashboard"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '2px',
      background: 'var(--border-default)',
      marginBottom: '40px'
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'white',
      padding: '24px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginBottom: '10px'
    }
  }, s.l), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-4xl)',
      fontWeight: 300
    }
  }, s.v))))), section === 'citas' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '24px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300
    }
  }, "Citas de hoy"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      border: '1px solid var(--border-default)',
      background: 'white'
    }
  }, [{
    k: 'todos',
    l: 'Todas'
  }, {
    k: 'confirmed',
    l: 'Confirmadas'
  }, {
    k: 'pending',
    l: 'Pendientes'
  }].map(f => /*#__PURE__*/React.createElement("button", {
    key: f.k,
    onClick: () => setFilter(f.k),
    style: {
      padding: '8px 16px',
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      background: filter === f.k ? 'var(--color-black)' : 'transparent',
      color: filter === f.k ? 'white' : 'var(--text-secondary)',
      border: 'none',
      borderRight: '1px solid var(--border-default)',
      cursor: 'pointer',
      transition: 'all 150ms'
    }
  }, f.l)))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'white',
      border: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '72px 1fr 1fr 96px 120px 36px',
      padding: '12px 24px',
      borderBottom: '1px solid var(--border-default)',
      background: 'var(--color-warm-50)'
    }
  }, ['Hora', 'Cliente', 'Servicio', 'Profesional', 'Estado', ''].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: th
  }, h))), visible.map((a, i) => {
    const sm = statusMeta[a.status];
    return /*#__PURE__*/React.createElement("div", {
      key: a.id,
      style: {
        display: 'grid',
        gridTemplateColumns: '72px 1fr 1fr 96px 120px 36px',
        padding: '15px 24px',
        borderBottom: i < visible.length - 1 ? '1px solid var(--border-subtle)' : 'none',
        alignItems: 'center',
        background: a.status === 'blocked' ? 'var(--color-warm-50)' : 'white',
        opacity: a.status === 'cancelled' ? 0.55 : 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: 500,
        color: a.status === 'blocked' ? 'var(--text-muted)' : 'inherit'
      }
    }, a.time), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        textDecoration: a.status === 'cancelled' ? 'line-through' : 'none',
        color: a.status === 'blocked' ? 'var(--text-muted)' : 'inherit'
      }
    }, a.client), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-xs)',
        color: 'var(--text-secondary)'
      }
    }, a.service), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-xs)',
        color: 'var(--text-secondary)'
      }
    }, a.pro), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        padding: '3px 10px',
        fontFamily: 'var(--font-body)',
        fontSize: '8px',
        fontWeight: 500,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        background: sm.bg,
        color: sm.color,
        border: `1px solid ${sm.border}`
      }
    }, sm.label)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'flex-end'
      }
    }, a.status !== 'blocked' && /*#__PURE__*/React.createElement("button", {
      style: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        color: 'var(--text-muted)',
        padding: '4px'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "14",
      height: "14",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "1"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "19",
      cy: "12",
      r: "1"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "5",
      cy: "12",
      r: "1"
    })))));
  }))), section === 'servicios' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '24px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300
    }
  }, "Servicios"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'var(--color-black)',
      color: 'white',
      border: 'none',
      padding: '10px 24px',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      cursor: 'pointer'
    }
  }, "+ Agregar")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'white',
      border: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '120px 1fr 96px 96px 80px',
      padding: '12px 24px',
      borderBottom: '1px solid var(--border-default)',
      background: 'var(--color-warm-50)'
    }
  }, ['Categoría', 'Servicio', 'Precio', 'Duración', ''].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: th
  }, h))), services.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'grid',
      gridTemplateColumns: '120px 1fr 96px 96px 80px',
      padding: '16px 24px',
      borderBottom: i < services.length - 1 ? '1px solid var(--border-subtle)' : 'none',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, s.cat), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500
    }
  }, s.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)'
    }
  }, s.price), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-secondary)'
    }
  }, s.dur), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      background: 'none',
      border: '1px solid var(--border-default)',
      padding: '6px 12px',
      cursor: 'pointer',
      color: 'var(--text-secondary)'
    }
  }, "Editar")))))), (section === 'bloqueos' || section === 'configuración') && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '60vh',
      flexDirection: 'column',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      textTransform: 'capitalize'
    }
  }, section), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, "Pr\xF3ximamente disponible.")))));
}
Object.assign(window, {
  AdminPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/pages/Admin.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/pages/Booking.jsx
try { (() => {
// pages/Booking.jsx

function BookingPage({
  navigate
}) {
  const [step, setStep] = React.useState(1);
  const [selectedCat, setSelectedCat] = React.useState(null);
  const [selectedPro, setSelectedPro] = React.useState(null);
  const [selectedDate, setSelectedDate] = React.useState(null);
  const [selectedTime, setSelectedTime] = React.useState(null);
  const [form, setForm] = React.useState({
    name: '',
    phone: '',
    comment: ''
  });
  const categories = [{
    id: 'corte',
    name: 'Corte',
    price: 'desde $5.000'
  }, {
    id: 'color',
    name: 'Color',
    price: 'desde $35.000'
  }, {
    id: 'tratamientos',
    name: 'Tratamientos',
    price: 'desde $20.000'
  }, {
    id: 'manicure',
    name: 'Manicure',
    price: 'desde $8.000'
  }];
  const professionals = [{
    id: 'eli',
    name: 'Eli',
    role: 'Estilista',
    init: 'E'
  }, {
    id: 'ori',
    name: 'Ori',
    role: 'Colorista',
    init: 'O'
  }, {
    id: 'valentina',
    name: 'Valentina',
    role: 'Manicurista',
    init: 'V'
  }, {
    id: 'any',
    name: 'Sin preferencia',
    role: 'Primer disponible',
    init: '—'
  }];

  // June 2026: rows Mon→Sun, June 1 = Monday
  const june = [[1, 2, 3, 4, 5, 6, 7], [8, 9, 10, 11, 12, 13, 14], [15, 16, 17, 18, 19, 20, 21], [22, 23, 24, 25, 26, 27, 28], [29, 30, null, null, null, null, null]];
  // di: 0=Mon … 5=Sat … 6=Sun  — closed Mon(0) and Sun(6)
  const closedDi = new Set([0, 6]);
  const times = ['09:30', '10:30', '11:30', '12:30', '13:30', '14:30', '15:30', '16:30', '17:30', '18:00'];
  const booked = new Set(['10:30', '13:30', '16:30']);
  const stepLabels = ['Servicio', 'Profesional', 'Fecha', 'Hora', 'Datos'];
  const BtnFwd = ({
    onClick,
    disabled,
    label
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    disabled: disabled,
    style: {
      background: disabled ? 'var(--color-warm-200)' : 'var(--color-black)',
      color: disabled ? 'var(--color-warm-500)' : 'white',
      border: 'none',
      padding: '14px 0',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      cursor: disabled ? 'not-allowed' : 'pointer',
      flex: 2,
      transition: 'all 200ms ease'
    }
  }, label || 'Continuar');
  const BtnBack = ({
    onClick
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      border: '1px solid var(--border-default)',
      padding: '14px 0',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      cursor: 'pointer',
      flex: 1
    }
  }, "Atr\xE1s");

  // ── Confirmation ────────────────────────────────────────
  if (step === 6) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: 'calc(100vh - 72px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--color-warm-50)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        maxWidth: '480px',
        padding: '64px 32px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 64,
        height: 64,
        borderRadius: '50%',
        background: 'var(--color-warm-900)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto 32px'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "22",
      height: "22",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "white",
      strokeWidth: "1.5",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("polyline", {
      points: "20 6 9 17 4 12"
    }))), /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--text-4xl)',
        fontWeight: 300,
        marginBottom: '16px'
      }
    }, "Reserva confirmada"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        color: 'var(--text-secondary)',
        lineHeight: 1.75,
        marginBottom: '40px'
      }
    }, "Te esperamos el ", selectedDate && `${selectedDate} de junio`, " a las ", /*#__PURE__*/React.createElement("strong", null, selectedTime, " hrs"), ".", /*#__PURE__*/React.createElement("br", null), "Recibir\xE1s una confirmaci\xF3n por WhatsApp."), /*#__PURE__*/React.createElement("div", {
      style: {
        border: '1px solid var(--border-default)',
        padding: '24px',
        background: 'white',
        marginBottom: '32px',
        textAlign: 'left'
      }
    }, [{
      l: 'Servicio',
      v: selectedCat
    }, {
      l: 'Profesional',
      v: selectedPro
    }, {
      l: 'Fecha',
      v: selectedDate ? `${selectedDate} Jun 2026` : ''
    }, {
      l: 'Hora',
      v: selectedTime ? `${selectedTime} hrs` : ''
    }, {
      l: 'Nombre',
      v: form.name
    }].map((r, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '8px 0',
        borderBottom: i < 4 ? '1px solid var(--border-subtle)' : 'none'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: '9px',
        fontWeight: 500,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        color: 'var(--text-muted)'
      }
    }, r.l), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        textTransform: 'capitalize'
      }
    }, r.v)))), /*#__PURE__*/React.createElement("button", {
      onClick: () => navigate('home'),
      style: {
        background: 'var(--color-black)',
        color: 'white',
        border: 'none',
        padding: '14px 40px',
        fontFamily: 'var(--font-body)',
        fontSize: '10px',
        fontWeight: 500,
        letterSpacing: '0.2em',
        textTransform: 'uppercase',
        cursor: 'pointer'
      }
    }, "Volver al inicio")));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 'calc(100vh - 72px)',
      background: 'var(--color-warm-50)',
      paddingBottom: '64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '720px',
      margin: '0 auto',
      padding: '64px 32px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '64px'
    }
  }, stepLabels.map((label, i) => {
    const n = i + 1;
    const active = step === n,
      done = step > n;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: label
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '8px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: '50%',
        background: done || active ? 'var(--color-black)' : 'transparent',
        border: `1px solid ${done || active ? 'var(--color-black)' : 'var(--border-default)'}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-body)',
        fontSize: '11px',
        fontWeight: 500,
        color: done || active ? 'white' : 'var(--text-muted)',
        transition: 'all 200ms'
      }
    }, done ? /*#__PURE__*/React.createElement("svg", {
      width: "12",
      height: "12",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "white",
      strokeWidth: "2",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("polyline", {
      points: "20 6 9 17 4 12"
    })) : n), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: '8px',
        fontWeight: 500,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        color: active ? 'var(--text-primary)' : 'var(--text-muted)',
        whiteSpace: 'nowrap'
      }
    }, label)), i < stepLabels.length - 1 && /*#__PURE__*/React.createElement("div", {
      style: {
        width: 60,
        height: 1,
        background: step > i + 1 ? 'var(--color-black)' : 'var(--border-default)',
        margin: '0 6px',
        marginBottom: '24px',
        transition: 'background 300ms'
      }
    }));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'white',
      border: '1px solid var(--border-default)',
      padding: '48px'
    }
  }, step === 1 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '8px'
    }
  }, "Elige un servicio"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginBottom: '40px'
    }
  }, "Selecciona la categor\xEDa que te interesa."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '2px',
      background: 'var(--border-default)',
      marginBottom: '40px'
    }
  }, categories.map(cat => /*#__PURE__*/React.createElement("div", {
    key: cat.id,
    onClick: () => setSelectedCat(cat.id),
    style: {
      background: selectedCat === cat.id ? 'var(--color-black)' : 'white',
      color: selectedCat === cat.id ? 'white' : 'inherit',
      padding: '32px 28px',
      cursor: 'pointer',
      transition: 'all 150ms ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-2xl)',
      fontWeight: 300,
      marginBottom: '4px'
    }
  }, cat.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      color: selectedCat === cat.id ? 'rgba(255,255,255,0.45)' : 'var(--text-muted)'
    }
  }, cat.price)))), /*#__PURE__*/React.createElement(BtnFwd, {
    disabled: !selectedCat,
    onClick: () => setStep(2)
  })), step === 2 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '8px'
    }
  }, "Elige un profesional"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginBottom: '40px'
    }
  }, "Todos son expertos en su especialidad."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px',
      background: 'var(--border-default)',
      marginBottom: '40px'
    }
  }, professionals.map(pro => /*#__PURE__*/React.createElement("div", {
    key: pro.id,
    onClick: () => setSelectedPro(pro.id),
    style: {
      background: selectedPro === pro.id ? 'var(--color-black)' : 'white',
      color: selectedPro === pro.id ? 'white' : 'inherit',
      padding: '18px 24px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      transition: 'all 150ms ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: '50%',
      background: selectedPro === pro.id ? 'rgba(255,255,255,0.12)' : 'var(--color-warm-100)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-body)',
      fontSize: '13px',
      fontWeight: 500,
      color: selectedPro === pro.id ? 'white' : 'var(--color-warm-600)',
      flexShrink: 0
    }
  }, pro.init), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500
    }
  }, pro.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      color: selectedPro === pro.id ? 'rgba(255,255,255,0.45)' : 'var(--text-muted)',
      marginTop: '2px'
    }
  }, pro.role)), selectedPro === pro.id && /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "white",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement(BtnBack, {
    onClick: () => setStep(1)
  }), /*#__PURE__*/React.createElement(BtnFwd, {
    disabled: !selectedPro,
    onClick: () => setStep(3)
  }))), step === 3 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '8px'
    }
  }, "Elige una fecha"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginBottom: '40px'
    }
  }, "Atendemos Mar\u2013Vie 9:30\u201319:00 \xB7 S\xE1b 10:00\u201318:00"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: '40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500
    }
  }, "Junio 2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7,1fr)',
      gap: '2px',
      marginBottom: '4px'
    }
  }, ['L', 'M', 'X', 'J', 'V', 'S', 'D'].map(d => /*#__PURE__*/React.createElement("div", {
    key: d,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.1em',
      color: 'var(--text-muted)',
      textAlign: 'center',
      padding: '6px 0'
    }
  }, d))), june.map((week, wi) => /*#__PURE__*/React.createElement("div", {
    key: wi,
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7,1fr)',
      gap: '2px',
      marginBottom: '2px'
    }
  }, week.map((day, di) => {
    const isClosed = closedDi.has(di);
    const isPast = day && day < 25;
    const isDisabled = !day || isClosed || isPast;
    const isSelected = selectedDate === day;
    const isToday = day === 25;
    return /*#__PURE__*/React.createElement("div", {
      key: di,
      onClick: () => !isDisabled && setSelectedDate(day),
      style: {
        height: 40,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        cursor: isDisabled ? 'default' : 'pointer',
        opacity: isDisabled ? 0.22 : 1,
        background: isSelected ? 'var(--color-black)' : isToday && !isSelected ? 'var(--color-warm-100)' : 'transparent',
        color: isSelected ? 'white' : 'inherit',
        fontWeight: isToday ? 500 : 400,
        transition: 'all 150ms',
        userSelect: 'none'
      }
    }, day);
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement(BtnBack, {
    onClick: () => setStep(2)
  }), /*#__PURE__*/React.createElement(BtnFwd, {
    disabled: !selectedDate,
    onClick: () => setStep(4)
  }))), step === 4 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '8px'
    }
  }, "Elige una hora"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginBottom: '40px'
    }
  }, selectedDate ? `Jueves ${selectedDate} de junio` : 'Horarios disponibles'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '2px',
      background: 'var(--border-default)',
      marginBottom: '40px'
    }
  }, times.map(t => {
    const taken = booked.has(t),
      sel = selectedTime === t;
    return /*#__PURE__*/React.createElement("div", {
      key: t,
      onClick: () => !taken && setSelectedTime(t),
      style: {
        background: sel ? 'var(--color-black)' : taken ? 'var(--color-warm-50)' : 'white',
        color: sel ? 'white' : taken ? 'var(--color-warm-300)' : 'inherit',
        padding: '18px 8px',
        textAlign: 'center',
        cursor: taken ? 'not-allowed' : 'pointer',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: sel ? 500 : 400,
        transition: 'all 150ms ease'
      }
    }, /*#__PURE__*/React.createElement("div", null, t), taken && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '8px',
        marginTop: '2px',
        letterSpacing: '0.05em'
      }
    }, "Ocupado"));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement(BtnBack, {
    onClick: () => setStep(3)
  }), /*#__PURE__*/React.createElement(BtnFwd, {
    disabled: !selectedTime,
    onClick: () => setStep(5)
  }))), step === 5 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '8px'
    }
  }, "Tus datos"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginBottom: '40px'
    }
  }, "Solo lo necesario para confirmar tu reserva."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
      marginBottom: '32px'
    }
  }, [{
    label: 'Nombre completo',
    key: 'name',
    type: 'text',
    ph: 'Tu nombre'
  }, {
    label: 'Teléfono',
    key: 'phone',
    type: 'tel',
    ph: '+56 9 XXXX XXXX'
  }, {
    label: 'Comentario',
    key: 'comment',
    type: 'text',
    ph: 'Opcional — alergias, largo del cabello...'
  }].map(f => /*#__PURE__*/React.createElement("div", {
    key: f.key,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, f.label), /*#__PURE__*/React.createElement("input", {
    type: f.type,
    placeholder: f.ph,
    value: form[f.key],
    onChange: e => setForm(prev => ({
      ...prev,
      [f.key]: e.target.value
    })),
    style: {
      background: 'transparent',
      border: 'none',
      borderBottom: '1px solid var(--border-default)',
      padding: '10px 0',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      outline: 'none',
      width: '100%',
      color: 'var(--text-primary)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-warm-50)',
      border: '1px solid var(--border-subtle)',
      padding: '16px 20px',
      marginBottom: '32px',
      display: 'flex',
      gap: '24px',
      flexWrap: 'wrap'
    }
  }, [{
    l: 'Servicio',
    v: selectedCat
  }, {
    l: 'Profesional',
    v: selectedPro
  }, {
    l: 'Fecha',
    v: selectedDate ? `${selectedDate} Jun` : ''
  }, {
    l: 'Hora',
    v: selectedTime
  }].map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '8px',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginBottom: '2px'
    }
  }, r.l), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500,
      textTransform: 'capitalize'
    }
  }, r.v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement(BtnBack, {
    onClick: () => setStep(4)
  }), /*#__PURE__*/React.createElement(BtnFwd, {
    disabled: !form.name || !form.phone,
    onClick: () => setStep(6),
    label: "Confirmar reserva"
  }))))));
}
Object.assign(window, {
  BookingPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/pages/Booking.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/pages/Gallery.jsx
try { (() => {
// pages/Gallery.jsx

function GalleryPage({
  navigate
}) {
  const [filter, setFilter] = React.useState('todos');
  const [hoveredItem, setHoveredItem] = React.useState(null);
  const filters = [{
    key: 'todos',
    label: 'Todos'
  }, {
    key: 'corte',
    label: 'Corte'
  }, {
    key: 'color',
    label: 'Color'
  }, {
    key: 'tratamientos',
    label: 'Tratamientos'
  }, {
    key: 'manicure',
    label: 'Manicure'
  }];
  const items = [{
    cat: 'color',
    tone: '#1A1917',
    label: 'Balayage'
  }, {
    cat: 'corte',
    tone: '#2B2926',
    label: 'Corte Mujer'
  }, {
    cat: 'color',
    tone: '#E8E2DA',
    label: 'Mechas'
  }, {
    cat: 'tratamientos',
    tone: '#C4B8A8',
    label: 'Keratina'
  }, {
    cat: 'corte',
    tone: '#3D3B37',
    label: 'Corte + Peinado'
  }, {
    cat: 'manicure',
    tone: '#F4F2EE',
    label: 'Semipermanente'
  }, {
    cat: 'color',
    tone: '#1A1917',
    label: 'Tinte completo'
  }, {
    cat: 'corte',
    tone: '#8B7E6E',
    label: 'Corte Hombre'
  }, {
    cat: 'color',
    tone: '#2B2926',
    label: 'Balayage'
  }, {
    cat: 'manicure',
    tone: '#E2DED8',
    label: 'Nail art'
  }, {
    cat: 'tratamientos',
    tone: '#1A1917',
    label: 'Hidratación'
  }, {
    cat: 'color',
    tone: '#C4B8A8',
    label: 'Decoloración'
  }];
  const visible = filter === 'todos' ? items : items.filter(it => it.cat === filter);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 40px 0',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1280px',
      margin: '0 auto',
      paddingBottom: '40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.25em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginBottom: '12px'
    }
  }, "Portfolio"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-5xl)',
      fontWeight: 300,
      lineHeight: 1,
      letterSpacing: '-0.03em'
    }
  }, "Galer\xEDa")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1280px',
      margin: '0 auto',
      display: 'flex',
      gap: '0'
    }
  }, filters.map(f => /*#__PURE__*/React.createElement("button", {
    key: f.key,
    onClick: () => setFilter(f.key),
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      padding: '18px 24px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: filter === f.key ? 'var(--text-primary)' : 'var(--text-muted)',
      borderBottom: filter === f.key ? '1px solid var(--color-black)' : '1px solid transparent',
      marginBottom: '-1px',
      transition: 'color 150ms ease'
    }
  }, f.label)))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1280px',
      margin: '0 auto',
      padding: '2px 40px 96px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '2px',
      marginTop: '2px'
    }
  }, visible.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: `${filter}-${i}`,
    onMouseEnter: () => setHoveredItem(i),
    onMouseLeave: () => setHoveredItem(null),
    style: {
      aspectRatio: '4/5',
      background: item.tone,
      position: 'relative',
      overflow: 'hidden',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(13,12,10,0.65)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      padding: '24px',
      opacity: hoveredItem === i ? 1 : 0,
      transition: 'opacity 200ms ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '8px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,0.45)',
      marginBottom: '4px'
    }
  }, item.cat), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.4rem',
      fontWeight: 300,
      color: 'white'
    }
  }, item.label)))))));
}
Object.assign(window, {
  GalleryPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/pages/Gallery.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/pages/Home.jsx
try { (() => {
// pages/Home.jsx — animated landing page (transitions, not animations, to survive re-renders)

function HomePage({
  navigate
}) {
  const [mounted, setMounted] = React.useState(false);
  const [svcVis, setSvcVis] = React.useState(false);
  const [galVis, setGalVis] = React.useState(false);
  const [hovSvc, setHovSvc] = React.useState(null);
  const [hovGal, setHovGal] = React.useState(null);
  const svcRef = React.useRef(null);
  const galRef = React.useRef(null);
  React.useEffect(() => {
    // Inject keyframes once — only blob/scan/bounce (NOT fade-up; those use CSS transitions)
    if (!document.getElementById('lpk-kf')) {
      const s = document.createElement('style');
      s.id = 'lpk-kf';
      s.textContent = `
        @keyframes lpkBlob1 {
          0%,100% { transform:translate(0,0) scale(1);          opacity:.42; }
          38%     { transform:translate(65px,-42px) scale(1.13); opacity:.64; }
          70%     { transform:translate(-18px,28px) scale(.93);  opacity:.34; }
        }
        @keyframes lpkBlob2 {
          0%,100% { transform:translate(0,0) scale(1);          opacity:.28; }
          34%     { transform:translate(-62px,46px) scale(1.2);  opacity:.46; }
          64%     { transform:translate(36px,-14px) scale(.9);   opacity:.22; }
        }
        @keyframes lpkBlob3 {
          0%,100% { transform:translate(0,0);        opacity:.16; }
          50%     { transform:translate(28px,-52px); opacity:.28; }
        }
        @keyframes lpkLineDraw {
          from { transform:scaleX(0); transform-origin:left center; }
          to   { transform:scaleX(1); transform-origin:left center; }
        }
        @keyframes lpkBounce {
          0%,100% { transform:translateX(-50%) translateY(0); }
          50%     { transform:translateX(-50%) translateY(7px); }
        }
      `;
      document.head.appendChild(s);
    }

    // Trigger hero transitions a frame after mount
    const t = setTimeout(() => setMounted(true), 60);

    // Scroll-reveal via IntersectionObserver
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.target === svcRef.current && e.isIntersecting) setSvcVis(true);
        if (e.target === galRef.current && e.isIntersecting) setGalVis(true);
      });
    }, {
      threshold: 0.12
    });
    if (svcRef.current) io.observe(svcRef.current);
    if (galRef.current) io.observe(galRef.current);
    return () => {
      clearTimeout(t);
      io.disconnect();
    };
  }, []);

  // CSS-transition based helpers — safe across re-renders (transitions don't restart
  // just because the transition property is written again with the same value)
  const fu = d => ({
    opacity: mounted ? 1 : 0,
    transform: mounted ? 'translateY(0px)' : 'translateY(26px)',
    transition: `opacity .72s cubic-bezier(.16,1,.3,1) ${d}s, transform .72s cubic-bezier(.16,1,.3,1) ${d}s`
  });
  const sr = (vis, d) => ({
    opacity: vis ? 1 : 0,
    transform: vis ? 'translateY(0px)' : 'translateY(22px)',
    transition: `opacity .6s cubic-bezier(.16,1,.3,1) ${d}s, transform .6s cubic-bezier(.16,1,.3,1) ${d}s`
  });
  const services = [{
    num: '01',
    name: 'Corte',
    desc: 'Corte artístico adaptado a tu morfología facial y estilo de vida.',
    price: 'desde $10.000'
  }, {
    num: '02',
    name: 'Color',
    desc: 'Técnicas de alta gama: Balayage, mechas, tinte, decoloración.',
    price: 'desde $35.000'
  }, {
    num: '03',
    name: 'Tratamientos',
    desc: 'Nutrición profunda y restauración de la fibra capilar.',
    price: 'desde $20.000'
  }];
  const tones = ['#1A1917', '#2B2926', '#E8E2DA', '#1A1917', '#C4B8A8', '#3D3B37'];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      height: '100vh',
      background: '#0D0C0A',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      width: '65%',
      height: '68%',
      top: '-10%',
      right: '-14%',
      background: 'radial-gradient(ellipse, rgba(139,126,110,.44) 0%, rgba(107,103,96,.16) 42%, transparent 70%)',
      animation: 'lpkBlob1 13s ease-in-out infinite',
      willChange: 'transform'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      width: '56%',
      height: '58%',
      bottom: '-10%',
      left: '-14%',
      background: 'radial-gradient(ellipse, rgba(80,72,60,.52) 0%, rgba(61,59,55,.2) 42%, transparent 70%)',
      animation: 'lpkBlob2 18s ease-in-out infinite',
      willChange: 'transform'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      width: '38%',
      height: '38%',
      top: '30%',
      left: '36%',
      background: 'radial-gradient(ellipse, rgba(176,162,145,.15) 0%, transparent 70%)',
      animation: 'lpkBlob3 22s ease-in-out infinite'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'linear-gradient(rgba(255,255,255,.016) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.016) 1px, transparent 1px)',
      backgroundSize: '80px 80px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to bottom, transparent 35%, rgba(10,9,8,.82) 100%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to right, rgba(10,9,8,.32) 0%, transparent 50%)'
    }
  })), mounted && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '38%',
      left: 0,
      right: 0,
      height: '1px',
      background: 'linear-gradient(to right, transparent 0%, rgba(255,255,255,.055) 25%, rgba(255,255,255,.055) 75%, transparent 100%)',
      transformOrigin: 'left center',
      animation: 'lpkLineDraw 2s cubic-bezier(.16,1,.3,1) .1s both',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: '84px',
      left: '56px',
      right: '50%',
      minWidth: '420px',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '8px',
      fontWeight: 500,
      letterSpacing: '0.35em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,.36)',
      marginBottom: '18px',
      ...fu(0.28)
    }
  }, "Puerto Varas \xB7 Chile"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 'clamp(54px,8.5vw,112px)',
      lineHeight: .88,
      letterSpacing: '-0.04em',
      color: 'white',
      marginBottom: '4px',
      ...fu(0.45)
    }
  }, "La"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 'clamp(54px,8.5vw,112px)',
      lineHeight: .88,
      letterSpacing: '-0.04em',
      color: 'white',
      marginBottom: '22px',
      ...fu(0.58)
    }
  }, "Pelukeria"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontStyle: 'italic',
      fontWeight: 300,
      fontSize: '.95rem',
      color: 'rgba(255,255,255,.3)',
      marginBottom: '40px',
      ...fu(0.8)
    }
  }, "Hair Salon"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px',
      ...fu(1.0)
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('booking'),
    style: {
      background: 'rgba(255,255,255,.1)',
      color: 'white',
      border: '1px solid rgba(255,255,255,.3)',
      padding: '13px 36px',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      cursor: 'pointer',
      backdropFilter: 'blur(10px)',
      WebkitBackdropFilter: 'blur(10px)',
      transition: 'all 200ms ease'
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = 'rgba(255,255,255,.9)';
      e.currentTarget.style.color = '#000';
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = 'rgba(255,255,255,.1)';
      e.currentTarget.style.color = 'white';
    }
  }, "Reservar hora"), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('services'),
    style: {
      background: 'transparent',
      color: 'rgba(255,255,255,.65)',
      border: '1px solid rgba(255,255,255,.15)',
      padding: '13px 28px',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      cursor: 'pointer',
      transition: 'all 200ms ease'
    },
    onMouseEnter: e => {
      e.currentTarget.style.color = 'white';
      e.currentTarget.style.borderColor = 'rgba(255,255,255,.32)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.color = 'rgba(255,255,255,.65)';
      e.currentTarget.style.borderColor = 'rgba(255,255,255,.15)';
    }
  }, "Ver servicios"))), mounted && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: '28px',
      left: '50%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      animation: 'lpkBounce 2.2s ease-in-out 1.4s infinite',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '7px',
      letterSpacing: '0.22em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,.17)'
    }
  }, "Scroll"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '1px',
      height: '36px',
      background: 'linear-gradient(to bottom, rgba(255,255,255,.14), transparent)'
    }
  }))), /*#__PURE__*/React.createElement("section", {
    ref: svcRef,
    style: {
      padding: '96px 48px',
      maxWidth: '1280px',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginBottom: '48px',
      paddingBottom: '20px',
      borderBottom: '1px solid var(--border-default)',
      ...sr(svcVis, 0)
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-4xl)',
      fontWeight: 300,
      letterSpacing: '-0.02em'
    }
  }, "Servicios"), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('services'),
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)',
      background: 'none',
      border: 'none',
      borderBottom: '1px solid var(--border-default)',
      paddingBottom: '1px',
      cursor: 'pointer'
    }
  }, "Ver todos \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: '1px',
      background: 'var(--border-default)'
    }
  }, services.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      ...sr(svcVis, 0.1 + i * 0.1)
    }
  }, /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHovSvc(i),
    onMouseLeave: () => setHovSvc(null),
    onClick: () => navigate('services'),
    style: {
      height: '100%',
      background: hovSvc === i ? '#000' : '#fff',
      color: hovSvc === i ? 'white' : 'inherit',
      padding: '48px 40px',
      cursor: 'pointer',
      transition: 'background 220ms ease, color 220ms ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: hovSvc === i ? 'rgba(255,255,255,.3)' : 'var(--text-muted)',
      marginBottom: '20px'
    }
  }, s.num), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300,
      marginBottom: '14px'
    }
  }, s.name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      lineHeight: 1.75,
      color: hovSvc === i ? 'rgba(255,255,255,.5)' : 'var(--text-secondary)',
      marginBottom: '28px'
    }
  }, s.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500
    }
  }, s.price)))))), /*#__PURE__*/React.createElement("section", {
    ref: galRef,
    style: {
      padding: '0 48px 96px',
      maxWidth: '1280px',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginBottom: '32px',
      paddingBottom: '20px',
      borderBottom: '1px solid var(--border-default)',
      ...sr(galVis, 0)
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-4xl)',
      fontWeight: 300,
      letterSpacing: '-0.02em'
    }
  }, "Portfolio"), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('gallery'),
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 500,
      letterSpacing: '0.15em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)',
      background: 'none',
      border: 'none',
      borderBottom: '1px solid var(--border-default)',
      paddingBottom: '1px',
      cursor: 'pointer'
    }
  }, "Ver galer\xEDa \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: '2px'
    }
  }, tones.map((tone, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      aspectRatio: '4/5',
      ...sr(galVis, 0.06 * i)
    }
  }, /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHovGal(i),
    onMouseLeave: () => setHovGal(null),
    onClick: () => navigate('gallery'),
    style: {
      width: '100%',
      height: '100%',
      background: tone,
      cursor: 'pointer',
      transition: 'opacity 250ms ease',
      opacity: hovGal !== null && hovGal !== i ? 0.6 : 1
    }
  }))))));
}
Object.assign(window, {
  HomePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/pages/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/pages/Services.jsx
try { (() => {
// pages/Services.jsx

function ServicesPage({
  navigate
}) {
  const [hovered, setHovered] = React.useState(null);
  const categories = [{
    id: 'corte',
    name: 'Corte',
    num: '01',
    services: [{
      name: 'Corte Mujer',
      desc: 'Lavado, corte artístico y secado profesional',
      price: '$15.000'
    }, {
      name: 'Corte Hombre',
      desc: 'Corte clásico con acabado y estilizado',
      price: '$10.000'
    }, {
      name: 'Corte + Peinado',
      desc: 'Corte y styling para ocasiones especiales',
      price: '$22.000'
    }, {
      name: 'Flequillo',
      desc: 'Reajuste de flequillo o puntas',
      price: '$5.000'
    }]
  }, {
    id: 'color',
    name: 'Color',
    num: '02',
    services: [{
      name: 'Tinte completo',
      desc: 'Color uniforme en toda la melena con productos premium',
      price: '$35.000'
    }, {
      name: 'Balayage',
      desc: 'Técnica de aclarado degradado pintado a mano',
      price: '$60.000'
    }, {
      name: 'Mechas',
      desc: 'Reflejos clásicos aplicados con papel de aluminio',
      price: '$45.000'
    }, {
      name: 'Decoloración',
      desc: 'Aclarado profesional de base capilar',
      price: '$40.000'
    }]
  }, {
    id: 'tratamientos',
    name: 'Tratamientos',
    num: '03',
    services: [{
      name: 'Hidratación profunda',
      desc: 'Mascarilla nutritiva de alta penetración capilar',
      price: '$20.000'
    }, {
      name: 'Keratina',
      desc: 'Alisado y nutrición intensiva sin formol',
      price: '$55.000'
    }, {
      name: 'Botox capilar',
      desc: 'Relleno y restauración de la fibra capilar dañada',
      price: '$45.000'
    }, {
      name: 'Olaplex',
      desc: 'Reconstrucción del enlace disulfuro capilar',
      price: '$30.000'
    }]
  }, {
    id: 'manicure',
    name: 'Manicure',
    num: '04',
    services: [{
      name: 'Manicure clásico',
      desc: 'Limpieza, modelado y esmaltado tradicional',
      price: '$8.000'
    }, {
      name: 'Semipermanente',
      desc: 'Esmaltado en gel de larga duración',
      price: '$14.000'
    }, {
      name: 'Pedicure',
      desc: 'Cuidado completo y estético de pies',
      price: '$15.000'
    }, {
      name: 'Nail art',
      desc: 'Decoración artística personalizada',
      price: '$18.000'
    }]
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 40px 48px',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1280px',
      margin: '0 auto',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.25em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginBottom: '12px'
    }
  }, "Cat\xE1logo"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-5xl)',
      fontWeight: 300,
      lineHeight: 1,
      letterSpacing: '-0.03em'
    }
  }, "Servicios")), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('booking'),
    style: {
      background: 'var(--color-black)',
      color: 'white',
      border: 'none',
      padding: '14px 32px',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      cursor: 'pointer'
    }
  }, "Reservar hora"))), categories.map((cat, ci) => /*#__PURE__*/React.createElement("section", {
    key: cat.id,
    style: {
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1280px',
      margin: '0 auto',
      padding: '0 40px',
      display: 'grid',
      gridTemplateColumns: '240px 1fr'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px 40px 40px 0',
      borderRight: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginBottom: '8px'
    }
  }, cat.num), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 300
    }
  }, cat.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      paddingLeft: '40px'
    }
  }, cat.services.map((svc, si) => {
    const key = `${ci}-${si}`;
    const isTop = si < 2;
    const isLeft = si % 2 === 0;
    return /*#__PURE__*/React.createElement("div", {
      key: si,
      onMouseEnter: () => setHovered(key),
      onMouseLeave: () => setHovered(null),
      style: {
        padding: '28px 0',
        borderBottom: isTop ? '1px solid var(--border-subtle)' : 'none',
        borderRight: isLeft ? '1px solid var(--border-subtle)' : 'none',
        paddingRight: isLeft ? '32px' : '0',
        paddingLeft: isLeft ? '0' : '32px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        gap: '16px',
        cursor: 'pointer',
        background: hovered === key ? 'var(--color-warm-50)' : 'transparent',
        transition: 'background 150ms ease',
        margin: isLeft ? '0 0 0 0' : '0'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: 500,
        marginBottom: '4px'
      }
    }, svc.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-xs)',
        color: 'var(--text-muted)',
        lineHeight: 1.65
      }
    }, svc.desc)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: 500,
        flexShrink: 0
      }
    }, svc.price));
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '96px 40px',
      textAlign: 'center',
      background: 'var(--color-warm-50)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-4xl)',
      fontWeight: 300,
      marginBottom: '16px'
    }
  }, "\xBFLista para tu pr\xF3xima visita?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      color: 'var(--text-secondary)',
      marginBottom: '40px'
    }
  }, "Mar a Vie 9:30 \u2013 19:00 \xB7 S\xE1b 10:00 \u2013 18:00"), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('booking'),
    style: {
      background: 'var(--color-black)',
      color: 'white',
      border: 'none',
      padding: '16px 48px',
      fontFamily: 'var(--font-body)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      cursor: 'pointer'
    }
  }, "Agendar ahora")));
}
Object.assign(window, {
  ServicesPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/pages/Services.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/shared.jsx
try { (() => {
// shared.jsx — Navbar & Footer (with adaptive glass style for home hero)

function LPKLogo({
  color = 'var(--color-black)',
  onClick
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: '1.4rem',
      lineHeight: 1,
      letterSpacing: '-0.03em',
      color,
      transition: 'color 350ms ease'
    }
  }, "LPk"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '7px',
      fontWeight: 500,
      letterSpacing: '0.24em',
      textTransform: 'uppercase',
      color,
      opacity: 0.55,
      transition: 'color 350ms ease'
    }
  }, "La Pelukeria"));
}
function LPKNavbar({
  navigate,
  currentPage
}) {
  const [scrolled, setScrolled] = React.useState(false);
  const [btnHov, setBtnHov] = React.useState(false);

  // On home page, track scroll to flip between glass-dark and glass-light
  React.useEffect(() => {
    if (currentPage !== 'home') {
      setScrolled(false);
      return;
    }
    const check = () => setScrolled(window.scrollY > window.innerHeight * 0.72);
    check();
    window.addEventListener('scroll', check, {
      passive: true
    });
    return () => window.removeEventListener('scroll', check);
  }, [currentPage]);
  const isHome = currentPage === 'home';
  const dark = isHome && !scrolled; // dark glass overlay on hero

  // Colors that transition between dark/light modes
  const fg = dark ? 'rgba(255,255,255,0.9)' : 'var(--color-black)';
  const fgMuted = dark ? 'rgba(255,255,255,0.45)' : 'var(--text-secondary)';
  const activeBdr = dark ? 'rgba(255,255,255,0.7)' : 'var(--color-black)';
  const links = [{
    key: 'home',
    label: 'Inicio'
  }, {
    key: 'services',
    label: 'Servicios'
  }, {
    key: 'gallery',
    label: 'Galería'
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: isHome ? 'fixed' : 'sticky',
      top: 0,
      width: '100%',
      zIndex: 100,
      height: 'var(--navbar-height)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 48px',
      background: dark ? 'rgba(13,12,10,0.28)' : 'rgba(255,255,255,0.94)',
      backdropFilter: 'blur(22px)',
      WebkitBackdropFilter: 'blur(22px)',
      borderBottom: dark ? '1px solid rgba(255,255,255,0.07)' : '1px solid var(--border-default)',
      transition: 'background 420ms ease, border-color 420ms ease'
    }
  }, /*#__PURE__*/React.createElement(LPKLogo, {
    color: fg,
    onClick: () => navigate('home')
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '40px'
    }
  }, links.map(link => {
    const active = currentPage === link.key;
    return /*#__PURE__*/React.createElement("button", {
      key: link.key,
      onClick: () => navigate(link.key),
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-xs)',
        fontWeight: 'var(--fw-medium)',
        letterSpacing: 'var(--ls-wider)',
        textTransform: 'uppercase',
        color: active ? fg : fgMuted,
        background: 'none',
        border: 'none',
        borderBottom: active ? `1px solid ${activeBdr}` : '1px solid transparent',
        paddingBottom: '2px',
        cursor: 'pointer',
        transition: 'color 300ms ease, border-color 300ms ease'
      }
    }, link.label);
  })), /*#__PURE__*/React.createElement("button", {
    onMouseEnter: () => setBtnHov(true),
    onMouseLeave: () => setBtnHov(false),
    onClick: () => navigate('booking'),
    style: {
      background: dark ? btnHov ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.1)' : btnHov ? 'transparent' : 'var(--color-black)',
      color: dark ? btnHov ? 'var(--color-black)' : 'rgba(255,255,255,0.9)' : btnHov ? 'var(--color-black)' : 'white',
      border: dark ? '1px solid rgba(255,255,255,0.28)' : '1px solid var(--color-black)',
      padding: '10px 26px',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: 'var(--ls-widest)',
      textTransform: 'uppercase',
      cursor: 'pointer',
      transition: 'all 250ms ease',
      backdropFilter: dark ? 'blur(10px)' : 'none'
    }
  }, "Reservar"));
}
function LPKFooter({
  navigate
}) {
  const col = {
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--text-sm)',
    color: 'rgba(255,255,255,0.45)',
    lineHeight: 2
  };
  const colLabel = {
    fontFamily: 'var(--font-body)',
    fontSize: '8px',
    fontWeight: 500,
    letterSpacing: '0.22em',
    textTransform: 'uppercase',
    opacity: 0.3,
    marginBottom: '14px',
    display: 'block'
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--color-warm-950)',
      color: 'white',
      padding: '64px 48px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1280px',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr',
      gap: '48px',
      paddingBottom: '40px',
      borderBottom: '1px solid rgba(255,255,255,0.07)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(LPKLogo, {
    color: "white"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'rgba(255,255,255,0.35)',
      lineHeight: 1.8,
      maxWidth: '280px',
      marginTop: '20px'
    }
  }, "Hair salon moderno y minimalista en Puerto Varas. Corte, color y tratamientos de alta gama.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: colLabel
  }, "Horario"), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("div", null, "Mar \u2013 Vie \xB7 9:30 \u2013 19:00"), /*#__PURE__*/React.createElement("div", null, "S\xE1bado \xB7 10:00 \u2013 18:00"), /*#__PURE__*/React.createElement("div", {
    style: {
      opacity: 0.4
    }
  }, "Lun \u2013 Dom \xB7 Cerrado"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: colLabel
  }, "Contacto"), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("div", null, "Puerto Varas, Chile"), /*#__PURE__*/React.createElement("div", null, "+56 9 2999 3799"), /*#__PURE__*/React.createElement("div", null, "@lapelukeria_pv")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingTop: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '9px',
      color: 'rgba(255,255,255,0.18)',
      letterSpacing: '0.1em'
    }
  }, "\xA9 2026 La Pelukeria \xB7 Puerto Varas"), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('admin'),
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '8px',
      color: 'rgba(255,255,255,0.15)',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      background: 'none',
      border: 'none',
      cursor: 'pointer'
    }
  }, "Admin \u2197"))));
}
Object.assign(window, {
  LPKLogo,
  LPKNavbar,
  LPKFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/shared.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Input = __ds_scope.Input;

})();
