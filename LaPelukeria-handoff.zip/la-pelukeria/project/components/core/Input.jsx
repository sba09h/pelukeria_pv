export function Input({
  label,
  placeholder,
  type = 'text',
  value,
  onChange,
  error,
  helperText,
  disabled = false,
  ...props
}) {
  const [focused, setFocused] = React.useState(false);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
      {label && (
        <label
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--text-xs)',
            fontWeight: 'var(--fw-medium)',
            letterSpacing: 'var(--ls-widest)',
            textTransform: 'uppercase',
            color: error
              ? '#8B3A3A'
              : focused
              ? 'var(--text-primary)'
              : 'var(--text-secondary)',
            transition: 'color var(--transition-fast)',
          }}
        >
          {label}
        </label>
      )}

      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: '100%',
          background: 'transparent',
          border: 'none',
          borderBottom: `1px solid ${
            error ? '#8B3A3A' : focused ? 'var(--color-black)' : 'var(--border-default)'
          }`,
          padding: 'var(--input-py) var(--input-px)',
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--text-base)',
          fontWeight: 'var(--fw-regular)',
          color: 'var(--text-primary)',
          outline: 'none',
          transition: 'border-color var(--transition-fast)',
          opacity: disabled ? 0.4 : 1,
          cursor: disabled ? 'not-allowed' : 'auto',
          borderRadius: 0,
        }}
        {...props}
      />

      {(error || helperText) && (
        <span
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--text-xs)',
            color: error ? '#8B3A3A' : 'var(--text-muted)',
            lineHeight: 'var(--lh-normal)',
          }}
        >
          {error || helperText}
        </span>
      )}
    </div>
  );
}
