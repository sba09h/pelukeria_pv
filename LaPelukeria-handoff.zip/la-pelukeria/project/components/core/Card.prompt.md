Surface container for services, appointments, gallery items, and modals.

```jsx
<Card variant="default" padding="md" hover>
  <h3>Balayage</h3>
  <p>Aclarado degradado a mano</p>
</Card>

<Card variant="flat" padding="lg">
  <Input label="Nombre" />
</Card>

<Card variant="dark" padding="md">
  <span style={{ color: 'white' }}>Cita confirmada</span>
</Card>

<Card variant="outlined" padding="sm" onClick={() => selectService(s)}>
  {service.name}
</Card>
```

Use `hover` prop only when the card is a clickable selection item (service selection, gallery, etc).
No rounding — `border-radius: 0` is the brand default.
