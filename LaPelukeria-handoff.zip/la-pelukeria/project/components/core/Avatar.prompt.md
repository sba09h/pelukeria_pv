Staff and client avatar — shows photo if available, initials as fallback.

```jsx
<Avatar name="Eli Cortés" size="md" />          {/* "EC" initials */}
<Avatar name="Ori Cabrini" size="lg" shape="circle" src="/staff/ori.jpg" />
<Avatar name="María García" size="sm" />
```

Sizes: `xs` (24px, inline), `sm` (32px, table rows), `md` (40px, default), `lg` (56px, staff cards), `xl` (72px, profile)
Shapes: `circle` (default, staff), `square` (admin list), `rounded` (4px, cards)
Initials background: `--color-warm-200` (warm gray), text: `--color-warm-700`.
