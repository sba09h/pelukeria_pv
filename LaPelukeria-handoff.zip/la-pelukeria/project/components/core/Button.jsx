export function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  onClick,
  children,
  ...props
}) {
  const [hovered, setHovered] = React.useState(false);

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--fw-medium)',
    fontSize: 'var(--text-xs)',
    letterSpacing: 'var(--ls-widest)',
    textTransform: 'uppercase',
    border: '1px solid',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--transition-base), color var(--transition-base), border-color var(--transition-base)',
    whiteSpace: 'nowrap',
    userSelect: 'none',
    width: fullWidth ? '100%' : undefined,
    borderRadius: 'var(--button-radius)',
  };

  const sizes = {
    sm: { padding: 'var(--button-py-sm) var(--button-px-sm)' },
    md: { padding: 'var(--button-py) var(--button-px)' },
    lg: { padding: 'var(--button-py-lg) var(--button-px-lg)' },
  };

  const resting = {
    primary:      { background: 'var(--color-black)', color: 'var(--color-white)', borderColor: 'var(--color-black)' },
    secondary:    { background: 'transparent',        color: 'var(--color-black)', borderColor: 'var(--color-black)' },
    ghost:        { background: 'transparent',        color: 'var(--text-secondary)', borderColor: 'transparent' },
    'dark-inverse': { background: 'var(--color-white)', color: 'var(--color-black)', borderColor: 'var(--color-white)' },
  };

  const hover = {
    primary:      { background: 'var(--color-white)',      color: 'var(--color-black)', borderColor: 'var(--color-black)' },
    secondary:    { background: 'var(--color-black)',      color: 'var(--color-white)', borderColor: 'var(--color-black)' },
    ghost:        { background: 'transparent',             color: 'var(--text-primary)', borderColor: 'transparent' },
    'dark-inverse': { background: 'var(--color-warm-100)', color: 'var(--color-black)', borderColor: 'var(--color-warm-100)' },
  };

  const variantStyle = hovered && !disabled ? hover[variant] : resting[variant];

  return (
    <button
      style={{ ...base, ...sizes[size], ...variantStyle }}
      disabled={disabled}
      onClick={!disabled ? onClick : undefined}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      {...props}
    >
      {children}
    </button>
  );
}
