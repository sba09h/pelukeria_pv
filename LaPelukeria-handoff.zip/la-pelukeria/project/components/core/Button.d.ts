/**
 * @startingPoint section="UI Elements" subtitle="Black/white CTA button — primary, secondary, ghost" viewport="700x180"
 */
export interface ButtonProps {
  /** Visual treatment */
  variant?: 'primary' | 'secondary' | 'ghost' | 'dark-inverse';
  /** Size — affects padding only, not font size */
  size?: 'sm' | 'md' | 'lg';
  /** Renders at full container width */
  fullWidth?: boolean;
  /** Disabled state — 40% opacity, non-interactive */
  disabled?: boolean;
  /** Click handler */
  onClick?: () => void;
  children: React.ReactNode;
}
