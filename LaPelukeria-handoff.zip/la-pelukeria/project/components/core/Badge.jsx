export function Badge({ status = 'pending', children }) {
  const styles = {
    pending: {
      background: 'var(--status-pending-bg)',
      color: 'var(--status-pending-text)',
      border: '1px solid var(--status-pending-border)',
    },
    confirmed: {
      background: 'var(--status-confirmed-bg)',
      color: 'var(--status-confirmed-text)',
      border: '1px solid var(--status-confirmed-border)',
    },
    cancelled: {
      background: 'var(--status-cancelled-bg)',
      color: 'var(--status-cancelled-text)',
      border: '1px solid var(--status-cancelled-border)',
      textDecoration: 'line-through',
    },
    blocked: {
      background: 'var(--status-blocked-bg)',
      color: 'var(--status-blocked-text)',
      border: '1px solid var(--status-blocked-border)',
    },
    new: {
      background: 'transparent',
      color: 'var(--color-black)',
      border: '1px solid var(--color-black)',
    },
  };

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '3px 10px',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-xs)',
        fontWeight: 'var(--fw-medium)',
        letterSpacing: 'var(--ls-wider)',
        textTransform: 'uppercase',
        borderRadius: 'var(--badge-radius)',
        whiteSpace: 'nowrap',
        ...styles[status],
      }}
    >
      {children}
    </span>
  );
}
