Status chip for appointment states — admin tables, booking confirmations.

```jsx
<Badge status="confirmed">Confirmada</Badge>
<Badge status="pending">Pendiente</Badge>
<Badge status="cancelled">Cancelada</Badge>
<Badge status="blocked">Bloqueada</Badge>
<Badge status="new">Nueva</Badge>
```

All statuses use the warm greyscale palette — no green/red/yellow.
The `cancelled` status automatically adds `text-decoration: line-through`.
