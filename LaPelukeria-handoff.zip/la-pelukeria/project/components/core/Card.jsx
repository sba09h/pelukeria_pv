export function Card({
  variant = 'default',
  padding = 'md',
  hover = false,
  onClick,
  style: extraStyle,
  children,
  ...props
}) {
  const [hovered, setHovered] = React.useState(false);

  const variants = {
    default: {
      background: 'var(--bg-primary)',
      border: '1px solid var(--border-default)',
      boxShadow: 'var(--card-shadow)',
    },
    flat: {
      background: 'var(--bg-secondary)',
      border: 'none',
      boxShadow: 'none',
    },
    dark: {
      background: 'var(--bg-dark)',
      border: 'none',
      boxShadow: 'none',
    },
    outlined: {
      background: 'transparent',
      border: '1px solid var(--border-default)',
      boxShadow: 'none',
    },
  };

  const paddings = {
    none: '0',
    sm:   'var(--space-4)',
    md:   'var(--card-p)',
    lg:   'var(--card-p-lg)',
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
      style={{
        ...variants[variant],
        padding: paddings[padding],
        borderRadius: 'var(--card-radius)',
        transition: 'box-shadow var(--transition-base), transform var(--transition-base)',
        cursor: onClick ? 'pointer' : undefined,
        ...(hover && hovered
          ? { boxShadow: 'var(--card-shadow-hover)', transform: 'translateY(-1px)' }
          : {}),
        ...extraStyle,
      }}
      {...props}
    >
      {children}
    </div>
  );
}
