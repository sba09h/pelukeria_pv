export function Avatar({ src, name = '', size = 'md', shape = 'circle', ...props }) {
  const sizes = { xs: 24, sm: 32, md: 40, lg: 56, xl: 72 };
  const px = sizes[size] ?? 40;
  const initials = name
    .split(' ')
    .filter(Boolean)
    .map((w) => w[0].toUpperCase())
    .slice(0, 2)
    .join('');

  const radius =
    shape === 'circle' ? '50%' : shape === 'square' ? '0' : 'var(--radius-md)';

  return (
    <div
      style={{
        width: px,
        height: px,
        borderRadius: radius,
        background: src ? 'transparent' : 'var(--color-warm-200)',
        color: 'var(--color-warm-700)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-body)',
        fontSize: px * 0.35,
        fontWeight: 'var(--fw-medium)',
        overflow: 'hidden',
        flexShrink: 0,
        userSelect: 'none',
        border: src ? 'none' : '1px solid var(--border-default)',
      }}
      {...props}
    >
      {src ? (
        <img
          src={src}
          alt={name}
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
      ) : (
        initials || '?'
      )}
    </div>
  );
}
