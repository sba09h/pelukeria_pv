CTA button — use for all primary and secondary actions in the La Pelukeria app.

```jsx
<Button variant="primary" size="md" onClick={handleReserve}>Reservar hora</Button>
<Button variant="secondary">Ver servicios</Button>
<Button variant="ghost">Cancelar</Button>
<Button variant="dark-inverse" size="lg">Reservar hora</Button>  {/* on dark hero bg */}
```

Variants:
- `primary` — black fill, white text → inverts on hover
- `secondary` — transparent fill, black border → black fill on hover
- `ghost` — no border, muted text → darkens on hover (nav links, cancel actions)
- `dark-inverse` — white fill, black text → use on dark/hero backgrounds

Sizes: `sm` (compact tables), `md` (default), `lg` (hero CTAs)
Never set font-weight bold — medium (500) is the max for this brand.
