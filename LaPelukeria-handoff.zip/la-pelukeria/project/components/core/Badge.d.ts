export interface BadgeProps {
  /** Appointment status — controls color and style */
  status: 'pending' | 'confirmed' | 'cancelled' | 'blocked' | 'new';
  /** Label text — usually the translated status name */
  children: React.ReactNode;
}
