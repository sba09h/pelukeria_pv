export interface InputProps {
  /** Field label — rendered as small caps above the input */
  label?: string;
  /** Placeholder text */
  placeholder?: string;
  /** HTML input type */
  type?: 'text' | 'email' | 'tel' | 'password' | 'number' | 'date';
  /** Controlled value */
  value?: string;
  /** Change handler */
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Validation error message — turns border and label red */
  error?: string;
  /** Helper text — shown below input when no error */
  helperText?: string;
  /** Disabled state */
  disabled?: boolean;
}
