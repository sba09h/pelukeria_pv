Minimalist line input — bottom border only, no box. Used in booking forms, admin modals.

```jsx
<Input label="Nombre" placeholder="Tu nombre completo" value={name} onChange={e => setName(e.target.value)} />
<Input label="Teléfono" type="tel" placeholder="+56 9 XXXX XXXX" />
<Input label="Email" type="email" error="Correo inválido" value={email} />
<Input label="Comentario" helperText="Opcional — alergias, largo del cabello, etc." />
```

Label renders as 11px uppercase caps. Error state turns border + label to a muted red (#8B3A3A).
Avoid using `type="number"` for Chilean phone numbers — use `type="tel"`.
