export interface AvatarProps {
  /** Image URL — shows initials if omitted */
  src?: string;
  /** Full name — used to derive initials (first two words) */
  name?: string;
  /** Size in px preset */
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  /** Shape variant */
  shape?: 'circle' | 'square' | 'rounded';
}
