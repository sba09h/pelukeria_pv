export interface CardProps {
  /** Visual style of the card */
  variant?: 'default' | 'flat' | 'dark' | 'outlined';
  /** Internal padding */
  padding?: 'none' | 'sm' | 'md' | 'lg';
  /** Enable hover effect (shadow lift + translateY) */
  hover?: boolean;
  /** Makes the card clickable — adds pointer cursor */
  onClick?: () => void;
  /** Additional inline styles */
  style?: React.CSSProperties;
  children: React.ReactNode;
}
