# La Pelukeria — Design System

**La Pelukeria** is a modern, minimalist hair salon in Puerto Varas, Chile. The brand
occupies a premium positioning: editorial black-and-white aesthetic, high-contrast
serif typography, and deliberate negative space. Think European fashion studio meets
artisan barbershop — nothing superfluous.

---

## Sources

| Source | Detail |
|--------|--------|
| Instagram | [@lapelukeria_pv](https://www.instagram.com/lapelukeria_pv/) — 294 posts, ~1,961 followers (Jun 2026) |
| WhatsApp | wa.me/56929993799 |
| Uploaded assets | Logo on taupe bg (`assets/logo-taupe.png`), Instagram profile (`assets/logo-instagram.png`) |
| Codebase / Figma | None provided — design system built from brand observation |

**Staff handles visible on Instagram**: @elycortamelpelo, @ori.cabrini

**Hours**: Mar–Vie 9:30–19:00 · Sáb 10:00–18:00 (closed Mon & Sun)

---

## Content Fundamentals

### Tone of voice
Formal-yet-warm. Uses Chilean "tú" register — approachable but never casual.
Polished, direct, zero fluff. Reads like a luxury product page, never like a social
media caption.

### Rules
- **No exclamation marks.** Confidence doesn't shout.
- **No emoji.** Ever.
- **Sentence case** for body copy, **Title Case** for service names, **ALL CAPS** for micro-labels only.
- CTAs are imperative verbs, minimal: "Reservar hora" / "Ver servicios" / "Agendar".
- Prices in CLP, format: `$15.000` (Chilean dot separator).
- Never superlatives: not "el mejor" or "único en Puerto Varas".
- Times: Chilean convention `9:30 – 19:00 hrs`.

### Copy examples
> "Corte artístico adaptado a tu morfología y estilo de vida."  
> "Reservar una hora es simple. Elige tu servicio, tu profesional y listo."  
> "Tratamientos de nutrición profunda para restaurar la fibra capilar."  
> "Mar a Vie 9:30 – 19:00 · Sáb 10:00 – 18:00"

---

## Visual Foundations

### Colors
Strictly **black & white** with a warm neutral support scale. No bright hues.

| Role | Value | Token |
|------|-------|-------|
| Primary black | `#000000` | `--color-black` |
| Primary white | `#FFFFFF` | `--color-white` |
| Dark background (hero) | `#1A1917` | `--color-warm-900` |
| Body text secondary | `#6B6760` | `--color-warm-500` |
| Default border | `#CCC9C3` | `--color-warm-200` |
| Taupe accent | `#8B7E6E` | `--color-taupe-500` |
| Light background | `#F4F2EE` | `--color-warm-50` |

### Typography
Two families only. No bold (700). Max weight: 500 (Medium).

| Role | Family | Weight | Size |
|------|--------|--------|------|
| Display / Hero | Cormorant | 300 Light | 88–120px |
| Section headings | Cormorant | 300–400 | 36–48px |
| Card headings | Cormorant | 400 | 28px |
| UI labels (caps) | DM Sans | 500 | 11px + 0.22em spacing |
| Body copy | DM Sans | 400 | 16–18px |
| Secondary / table | DM Sans | 400 | 13px |

**⚠️ Font substitution**: Cormorant (Google Fonts) replaces the brand's original
editorial serif (not identified from provided materials). DM Sans replaces any
original geometric sans. Please supply original `.woff2` files.

### Backgrounds
- **Dominant**: pure white — all cards, panels, page default
- **Hero / dark sections**: `#1A1917` (warm-900), never CSS `black`
- **Secondary sections**: `#F4F2EE` (warm-50)
- **No gradients in UI.** No textures. No patterns.
- Hero may use a dark color-wash overlay over photography.

### Borders & Dividers
- Always 1px — never 2px or thicker for structural lines
- Default: `--color-warm-200` (#CCC9C3)
- Interactive/focus: black (#000000)
- Section dividers replace visual margin — sections are separated by border-top lines, not gap

### Corner Radius
**Zero rounding** throughout. Sharp right angles are an intentional editorial choice.
- Cards: 0px
- Buttons: 0px
- Inputs: 0px
- Badges: 0px (exception: avatar uses 50% circle)

### Shadows
Barely perceptible — warm-tinted, never cool or blue:
- Cards at rest: `0 1px 3px rgba(26,25,23,0.06)`
- Cards on hover: `0 10px 20px rgba(26,25,23,0.08)`
- Admin sidebar uses a right-side border (no shadow)

### Animation
- Base: `200ms ease-out` — fast, no spring, no bounce
- Reveals/enter: `550ms cubic-bezier(0.16, 1, 0.3, 1)`
- No infinite decorative loops
- No scale transforms on interactive elements (color swap only on hover)
- Cards on hover: `translateY(-1px)` + shadow deepening is acceptable

### Hover States
- **Primary button**: black bg → white bg, white text → black text (border stays)
- **Secondary button**: white bg → black bg, black text → white text
- **Service cards**: white bg → black bg, full invert
- **Gallery items**: dark overlay appears over image
- **Links**: opacity 0.6 or animated bottom border

### Cards
White bg, 1px warm-200 border, `--shadow-sm`. No rounding. On hover: shadow lifts.
Dark variant: black bg, no border, white text.

### Layout
- Max content width: **1280px**, centered
- Horizontal page gutter: **40px** desktop / **20px** mobile
- Navbar: **72px** height, sticky, white bg with 1px bottom border
- Admin sidebar: **260px** wide, black bg with 1px right border
- Section vertical padding: **96px** top/bottom (--space-24)
- Column gap: **24px**

### Imagery & Photography
- **Mood**: moody, editorial, studio-lit, high contrast
- **Color vibe**: warm tones on dark backgrounds — never bright or saturated
- **Aspect ratio**: 4:5 portrait for gallery grid items
- **Never**: casual phone snapshots, over-filtered or bright images

---

## Iconography

No external icon library in the current brand. The primary symbol is the logo monogram.

**Logo**: "LPk" where the lowercase *k* has scissor blades integrated into its diagonal
strokes. Below: "LA PELUKERIA" in thin all-caps editorial serif, "PUERTO VARAS" in small
spaced capitals.

**Logo files**:
- `assets/logo-taupe.png` — logo on warm taupe background (editorial/social use)
- `assets/logo-instagram.png` — Instagram profile screenshot (reference only)

**In web UI**, the logo is rendered as styled text:
```
LPk            ← Cormorant / 300 / large
LA PELUKERIA   ← DM Sans / 500 / 11px / 0.22em tracking / uppercase
PUERTO VARAS   ← DM Sans / 300 / 9px / 0.2em tracking / uppercase / 50% opacity
```

**For functional icons** (navigation, forms, admin):
- Prefer minimal inline `<svg>` with `stroke: currentColor`, `stroke-width: 1.5`, no fill
- Heroicons Outline (CDN) if a full set is needed
- Never emoji as icons

---

## Index

```
/
├── styles.css             ← Global entry (consumers import this one file)
├── readme.md              ← This file
├── SKILL.md               ← Agent skill definition
│
├── tokens/
│   ├── fonts.css          ← Google Fonts (Cormorant + DM Sans)
│   ├── colors.css         ← Color scale + semantic tokens
│   ├── typography.css     ← Font families, sizes, weights, leading, tracking
│   ├── spacing.css        ← 4px-base spacing + layout/component tokens
│   ├── effects.css        ← Shadows, radii, motion tokens
│   └── base.css           ← CSS reset + body defaults
│
├── assets/
│   ├── logo-taupe.png     ← Brand logo on warm taupe background
│   └── logo-instagram.png ← Instagram profile (reference)
│
├── guidelines/            ← Specimen cards (Design System tab — foundation group)
│   ├── colors-primary.card.html
│   ├── colors-neutral.card.html
│   ├── colors-taupe.card.html
│   ├── colors-semantic.card.html
│   ├── type-display.card.html
│   ├── type-body.card.html
│   ├── type-scale.card.html
│   ├── spacing.card.html
│   ├── effects-shadows.card.html
│   ├── effects-radius.card.html
│   ├── brand-logo.card.html
│   └── brand-voice.card.html
│
├── components/
│   └── core/
│       ├── Button.jsx / .d.ts / .prompt.md
│       ├── Badge.jsx  / .d.ts / .prompt.md
│       ├── Input.jsx  / .d.ts / .prompt.md
│       ├── Card.jsx   / .d.ts / .prompt.md
│       ├── Avatar.jsx / .d.ts / .prompt.md
│       └── components.card.html
│
└── ui_kits/
    └── web_app/
        ├── index.html       ← Full interactive web app prototype
        ├── shared.jsx       ← Navbar, Footer, Logo
        └── pages/
            ├── Home.jsx
            ├── Services.jsx
            ├── Gallery.jsx
            ├── Booking.jsx
            └── Admin.jsx
```
